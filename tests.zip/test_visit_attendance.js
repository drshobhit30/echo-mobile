/* M1 fix pinned: attendance vs money. Rules:
   1. a CANCELLED bill still counts as a visit — the patient was in the chair;
   2. drafts and credit notes still do NOT count as visits;
   3. To Verify fires off a cancelled-bill visit (a postponed task whose
      patient came back is flagged even when the return visit's bill was
      later cancelled);
   4. follow-up ELIGIBILITY keeps its stricter rule — a cancelled bill alone
      raises no follow-up call (Work Pending owns that patient instead). */
'use strict';
const assert = require('assert');
const { loadApp } = require('./harness/load_app');
const app = loadApp(process.env.APP_FILE || 'echo-dental-collection-log.html');
const H = app.__hook;
let n = 0; const ok = (c, m) => { assert(c, m); n++; };

(async () => {
  H.set('getAllEntries', async () => []);
  H.set('getAllLabCases', async () => []);
  H.set('getAllBills', async () => [
    { billId:'c1', patientId:'20001', patientName:'Cancelled Only', status:'finalized',
      grandTotal:500, date:'2026-08-20', cancellation:{ at:'2026-08-20' } },
    { billId:'d1', patientId:'20002', patientName:'Draft Only', status:'draft',
      grandTotal:300, date:'2026-08-20' },
    { billId:'n1', patientId:'20003', patientName:'CN Only', status:'finalized',
      grandTotal:-400, date:'2026-08-20', docType:'credit' },
    { billId:'r1', patientId:'20004', patientName:'Regular', status:'finalized',
      grandTotal:800, date:'2026-08-19' },
  ]);
  H.set('lastVisitMapCache', null);   // fresh pass

  const seen = await H.get('_buildLastVisitMap')();
  ok(seen.has('20001'), 'cancelled-bill-only patient HAS a visit now (the audit gap, closed)');
  ok(seen.get('20001').date === '2026-08-20' && seen.get('20001').what === 'bill',
     'and it carries the right date and kind');
  ok(!seen.has('20002'), 'a draft still is not a visit');
  ok(!seen.has('20003'), 'a credit note still is not a visit');
  ok(seen.has('20004'), 'ordinary bills unchanged');

  // Rule 3: To Verify fires off that visit — real predicates, real txoBackIn.
  const task = { id:'t1', patientId:'20001', patientName:'Cancelled Only',
                 status:'advised', nextActionDate:'2026-12-01',
                 createdAt:'2026-08-01T10:00:00.000Z', updatedAt:'2026-08-01T10:00:00.000Z' };
  const back = H.get('txoBackIn')([task], seen, H.get('todayStr')());
  ok(back.length === 1 && back[0].task.id === 't1',
     'a postponed task is flagged To Verify by a cancelled-bill visit');

  // Rule 4: follow-up eligibility unchanged.
  ok(H.get('isFollowupEligibleBill')({ status:'finalized', cancellation:{at:'x'} }) === false,
     'a cancelled bill still raises no follow-up call by itself');

  console.log('test_visit_attendance: ' + n + ' assertions OK');
})().catch(e => { console.error(e); process.exit(1); });
