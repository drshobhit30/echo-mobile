/* Perf #1 pinned, with COUNTED disk reads — the same proof standard the
   entries index got. Rules:
   1. cold (no index): every case file is read once, then the index is
      written for next time;
   2. warm (index agrees with the listing): ONE content read — the index —
      and zero case-file reads;
   3. the listing stays the authority: a case the other machine added makes
      the key sets disagree, and the whole folder is re-read (never a stale
      serve);
   4. a save through storeSet patches the index file (the funnel), so the
      next read stays on the fast path with the NEW value;
   5. a corrupt case file blocks index-writing — a broken read is never
      baked into the fast path;
   6. invalidateCacheCategory('labcase:') drops the index from the cache
      with its category — the exact two-layer staleness that bit bills. */
'use strict';
const assert = require('assert');
const { loadApp } = require('./harness/load_app');
const app = loadApp(process.env.APP_FILE || 'echo-dental-collection-log.html');
const H = app.__hook;
let n = 0; const ok = (c, m) => { assert(c, m); n++; };
const eq = (a, b, m) => { assert.strictEqual(a, b, m + ` (got ${a}, want ${b})`); n++; };

(async () => {
  // A tiny fake folder at the raw layer; storeGet/storeSet run for real above it.
  const disk = new Map();
  const readLog = [];
  disk.set('labcase:a', JSON.stringify({ id:'a', patientId:'10001', workType:'Crown', dateSent:'2026-08-20' }));
  disk.set('labcase:b', JSON.stringify({ id:'b', patientId:'10002', workType:'Denture' }));
  H.set('folderReady', () => true);
  H.set('_storeGetRaw', async (k) => { readLog.push(k); return disk.has(k) ? disk.get(k) : null; });
  H.set('_storeSetRaw', async (k, v) => { disk.set(k, v); return 'ok'; });
  H.set('storeListKeys', async (prefix) =>
    Array.from(disk.keys()).filter(k => k.startsWith(prefix) && k !== 'labcases-index'));
  const fresh = () => { H.set('allLabCasesCache', null); };
  const cacheDel = (k) => H.get('fileContentCache').delete(k);

  // 1. cold
  let cases = await H.get('getAllLabCases')();
  eq(cases.length, 2, 'cold read returns both cases');
  ok(disk.has('labcases-index'), 'and writes the index for next time');
  ok(readLog.filter(k => k.startsWith('labcase:')).length === 2, 'each file read once');

  // 2. warm: drop parsed + content caches (a real refocus), keep the index file
  fresh(); cacheDel('labcase:a'); cacheDel('labcase:b'); cacheDel('labcases-index');
  readLog.length = 0;
  cases = await H.get('getAllLabCases')();
  eq(cases.length, 2, 'warm read still returns both');
  eq(readLog.filter(k => k.startsWith('labcase:')).length, 0, 'ZERO case-file reads on the warm path');
  eq(readLog.filter(k => k === 'labcases-index').length, 1, 'exactly one read — the index');

  // 3. the other machine adds a case → listing disagrees → full re-read
  disk.set('labcase:c', JSON.stringify({ id:'c', patientId:'10003', workType:'Aligner' }));
  fresh(); cacheDel('labcases-index'); cacheDel('labcase:c'); readLog.length = 0;
  cases = await H.get('getAllLabCases')();
  eq(cases.length, 3, 'foreign case appears — never a stale serve');
  ok(readLog.filter(k => k.startsWith('labcase:')).length >= 3, 'mismatch re-reads the folder');

  // 4. a save through storeSet patches the index (the funnel)
  const changed = { id:'b', patientId:'10002', workType:'Denture', dateDelivered:'2026-08-24' };
  await H.get('storeSet')('labcase:b', JSON.stringify(changed));
  const idx = JSON.parse(disk.get('labcases-index'));
  ok(idx.cases.some(c => c.id === 'b' && c.dateDelivered === '2026-08-24'),
     'the index file carries the new value without a rebuild');
  fresh(); cacheDel('labcases-index'); readLog.length = 0;
  cases = await H.get('getAllLabCases')();
  ok(cases.some(c => c.id === 'b' && c.dateDelivered === '2026-08-24')
     && readLog.filter(k => k.startsWith('labcase:')).length === 0,
     'next read serves the new value from the fast path');

  // 5. corrupt file blocks index-writing
  disk.set('labcase:x', '{truncated');
  disk.delete('labcases-index');
  fresh(); cacheDel('labcases-index'); cacheDel('labcase:x');
  await H.get('getAllLabCases')();
  ok(!disk.has('labcases-index'), 'no index written while a case file is unreadable');
  disk.delete('labcase:x');

  // 6. category invalidation drops the index from the CACHE too
  fresh(); cacheDel('labcases-index');
  await H.get('getAllLabCases')();               // repopulates cache with the index
  ok(H.get('fileContentCache').has('labcases-index'), 'index cached after a read');
  H.get('invalidateCacheCategory')('labcase:');
  ok(!H.get('fileContentCache').has('labcases-index'),
     'invalidating the category takes its index with it — the bills lesson, pinned');

  console.log('test_labcases_index: ' + n + ' assertions OK');
})().catch(e => { console.error(e); process.exit(1); });
