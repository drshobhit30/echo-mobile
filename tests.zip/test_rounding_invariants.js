/* L3 "executed" — by PINNING, not by changing the math, and the why matters:
   round2() has the classic binary-float edge (1.005 → 1.00, one paisa in a
   rare in-between step). "Fixing" round2 would make the app re-derive an
   EXISTING bill's subtotal a paisa differently the next time that bill is
   opened for edit — and at an exact .50 boundary that paisa flips the
   whole-rupee grand total by ₹1. A frozen figure that changes on reopen is
   real damage; a paisa-shaped quirk that the books absorb is none. So the
   rounding stays byte-identical, and this file pins the invariants that
   make it harmless:
   1. every derived figure is the SAME round2 everywhere, so both sides of
      every identity share the quirk and still balance;
   2. subtotal − pharmacy discount + roundOff = grandTotal, exactly, on
      float-nasty shapes;
   3. the grand total is always a whole rupee, with the paise sitting
      visibly in the Round Off line;
   4. a credit note remains an exact mirror of its sale on those same nasty
      shapes — no stranded paisa, no stranded rupee. */
'use strict';
const assert = require('assert');
const { loadApp } = require('./harness/load_app');
const app = loadApp(process.env.APP_FILE || 'echo-dental-collection-log.html');
const H = app.__hook;
let n = 0; const ok = (c, m) => { assert(c, m); n++; };
const eq = (a, b, m) => { assert.strictEqual(a, b, m + ` (got ${a}, want ${b})`); n++; };

(async () => {
  const round2 = H.get('round2');
  const RB = H.get('recomputeBillTotals');

  // The quirk itself, on record — if a future engine changes it, this fails
  // and the impact on stored bills must be thought through BEFORE shipping.
  eq(round2(1.005), 1, 'the known float edge, pinned as-is on purpose');

  // Float-nasty line amounts: 10.05 × 10% off = 9.045…, 3 × 33.335, etc.
  const nasty = () => ([
    { category:'procedure', amount: round2(1 * 10.05 * 0.9) },
    { category:'procedure', amount: round2(3 * 33.335) },
    { category:'pharmacy',  amount: round2(7 * 14.235) },
    { category:'pharmacy',  amount: round2(1 * 0.005) },
  ]);

  const sale = { items: nasty(), pharmDiscount: 12.345 };
  RB(sale);
  eq(round2(sale.subtotal - sale.pharmDiscount + sale.roundOff), sale.grandTotal,
     'identity holds on float-nasty shapes');
  eq(sale.grandTotal, Math.trunc(sale.grandTotal), 'grand total is a whole rupee');
  ok(Math.abs(sale.roundOff) < 1, 'the paise sit visibly in Round Off, never more than one rupee');

  // The mirror: same lines negated, same discount magnitude.
  const cn = { items: nasty().map(it => ({ ...it, amount: -it.amount })),
               pharmDiscount: 12.345 };
  RB(cn);
  eq(round2(cn.subtotal - cn.pharmDiscount + cn.roundOff), cn.grandTotal, 'identity holds on the CN');
  eq(sale.grandTotal + cn.grandTotal, 0, 'CN mirrors the sale exactly — nothing stranded');
  /* The second face of the quirk, pinned as-is: at an EXACT half-paisa
     input (x.xx5 — the discount field is free-typed, so a 3-decimal entry
     CAN reach it, though nobody prices in third-paise), round2(x) and
     round2(−x) differ by one paisa, so the CN's printed discount LINE can
     decompose a paisa differently from its sale's. The grand totals still
     mirror exactly (asserted above and below) because Round Off absorbs it
     and each document satisfies its own identity — so no money moves, only
     the paise split between two cosmetic lines. Changing round2 to remove
     this would nudge every exact-half-paisa figure app-wide for zero money
     benefit; the one rupee-level consequence this family ever had was the
     grandTotal case, already fixed with the magnitude trick. */
  eq(round2(round2(12.345) + round2(-12.345)), 0.01,
     'the half-paisa asymmetry itself, pinned so a future change is a conscious one');
  ok(Math.abs(sale.pharmDiscount + cn.pharmDiscount) <= 0.01,
     'discount lines mirror to within that one documented paisa');

  // And the half-rupee boundary where a changed round2 would flip a rupee:
  const edgeSale = { items: [{ category:'procedure', amount: 1250.5 }], pharmDiscount: 0 };
  const edgeCn   = { items: [{ category:'procedure', amount: -1250.5 }], pharmDiscount: 0 };
  RB(edgeSale); RB(edgeCn);
  eq(edgeSale.grandTotal + edgeCn.grandTotal, 0, 'half-rupee boundary still mirrors to zero');

  console.log('test_rounding_invariants: ' + n + ' assertions OK');
})().catch(e => { console.error(e); process.exit(1); });
