/* Two mobile changes.

   A. FRESH START. The app remembered the tab you left on, for ever. Coming
      back the next morning and landing on last night's Outstanding list is
      disorienting precisely because it looks like today's screen. The tab
      is now remembered only for a short window; past it, the app opens on
      Day, on today.
   B. ESTIMATES. Proposed treatment shows on the patient, because "what did
      the doctor say it would cost?" is asked away from the desk as often as
      at it. It must be counted NOWHERE: an estimate is a draft. */
'use strict';
const assert = require('assert');
const fs = require('fs');
const path = require('path');
const vm = require('vm');
let n = 0; const ok = (c, m) => { assert(c, m); n++; };

const MOB = process.env.MOBILE_FILE || 'index.html';
const SW = process.env.SW_FILE || path.join(path.dirname(MOB), 'sw.js');
const src = fs.readFileSync(MOB, 'utf-8');

// ---- A: run the actual restore logic, both sides of the window ----
const restoreSrc = (src.match(/let currentView = 'day';\n try\{[\s\S]*?\}catch\(e\)\{\}/) ||
                    src.match(/let currentView = 'day';\ntry\{[\s\S]*?\}catch\(e\)\{\}/))[0];
const windowSrc = src.match(/const VIEW_MEMORY_MS = [^;]+;/)[0];
const run = (savedView, ageMs) => {
  const store = { echoDental_view: savedView, echoDental_view_at: String(Date.now() - ageMs) };
  const sandbox = {
    Date, Number, console,
    localStorage: { getItem: (k) => (k in store ? store[k] : null) },
    document: { querySelectorAll: () => [] },
    KNOWN_VIEWS: ['day','month','patient','report']
  };
  vm.createContext(sandbox);
  vm.runInContext("const VIEW_KEY='echoDental_view'; const VIEW_AT_KEY='echoDental_view_at';\n"
    + windowSrc + '\n' + restoreSrc + '\nthis.view = currentView;', sandbox);
  return sandbox.view;
};
ok(run('report', 60 * 1000) === 'report', 'a minute away — the tab you left on is kept');
ok(run('report', 60 * 60 * 1000) === 'day', 'an hour away — opens fresh on Day');
ok(run('report', 12 * 60 * 60 * 1000) === 'day', 'next morning — opens fresh on Day');
ok(run('nonsense', 1000) === 'day', 'an unknown value still falls through to Day');
ok(/localStorage\.setItem\(VIEW_AT_KEY, String\(Date\.now\(\)\)\)/.test(src),
   'the timestamp is written every time the tab changes');

// ---- B: estimates shown, counted nowhere ----
ok(/id="pdEstimateBlock" class="hidden"/.test(src), 'the estimates block starts hidden');
ok(/eBlock\.classList\.toggle\('hidden', estimates\.length === 0\)/.test(src),
   'and stays hidden for a patient with none');
ok(/b\.status === 'draft' && b\.estimate/.test(src), 'it selects estimates specifically');
ok(/status !== 'draft'/.test(src), 'while the bills list still excludes every draft');
ok(/'<div class="bill-status">not billed<\/div>'/.test(src),
   'each row says the money is not billed — a figure by a name reads as owed otherwise');
/* Matches a CALL, not the word: the comment explaining why the maths is
   local mentions the helper by name, and a bare word-search flagged the
   explanation as the offence. */
ok(!/daysBetween\s*\(/.test(src),
   'no call to a desktop-only helper — that throws inside a render and blanks the screen');
/* The balance is computed from payments and non-draft bills, so an estimate
   cannot reach it. Pinned because it is the thing that must never break. */
ok(/computePendingFromData\(bills, entries\)/.test(src), 'the balance still comes from the money paths');

/* THE REASON IT COULD NOT BE SEEN: the patient list was built only from
   bills that COUNT AS MONEY, which rightly excludes drafts — so a patient
   whose only record was an estimate could not be found by name, and the
   section on their page was unreachable. Listed for search only; the
   balance is still computed from the money test. */
ok(/b\.status === 'draft' && b\.estimate\)\{\s*\n\s*note\(b\.patientId/.test(src),
   'a patient with only an estimate is findable by name');
ok(/if\(billCountsAsMoney\(b\)\) note\(/.test(src),
   'while the money test still governs what counts as money');
ok(/declinedAt/.test(src),
   'a declined estimate is not raised on the phone');

/* Built to look exactly like the bill rows and then left inert, which reads
   as broken rather than as read-only. */
ok(/class="pay-row tappable" data-estimate=/.test(src), 'estimate rows are tappable');
ok(/querySelectorAll\('\.pay-row\[data-estimate\]'\)[\s\S]{0,220}openBillSheet\(rec\)/.test(src),
   'and tapping one opens the detail sheet');
ok(/bill\.status === 'draft' && bill\.estimate\)\{[\s\S]{0,400}not billed and not owed/.test(src),
   'the sheet calls it a treatment estimate, not a draft, and says nothing is owed');
ok(/bits\.push\('Estimate'\)/.test(src),
   'and its header does not read as a bill missing its number');

ok(/CACHE_VERSION = 'echo-nexus-v25'/.test(fs.readFileSync(SW, 'utf-8')), 'service worker bumped to v18');

console.log('test_mobile_estimates_and_fresh_start: ' + n + ' assertions OK');
