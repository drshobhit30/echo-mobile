/* Consultation notes — what was said, to be read next time.
   Rules:
   1. RECEPTION CAN WRITE THEM. Admin-only was the old rule and it failed
      SILENTLY: the function returned false and the screen said nothing, so
      a note typed at the desk vanished on Enter. The conversation happens
      at the desk as often as in the chair.
   2. Striking a note stays admin-only — writing history is everyone's job,
      editing it is not.
   3. A note can be flagged "raise this when the patient next visits", and
      that note appears at the TOP of the record, not in date order down the
      history: a note that has to be scrolled to is a note that gets missed.
   4. Marking it reviewed clears the FLAG only — the note itself stays on
      the record for good, like every other note.
   5. A failed save is said out loud. */
'use strict';
const assert = require('assert');
const fs = require('fs');
const { loadApp } = require('./harness/load_app');
const FILE = process.env.APP_FILE || 'echo-dental-collection-log.html';
const app = loadApp(FILE);
const H = app.__hook;
let n = 0; const ok = (c, m) => { assert(c, m); n++; };

(async () => {
  let saved = null;
  H.set('folderReady', () => true);
  H.set('getPatientNotesLog', async () => saved ? JSON.parse(JSON.stringify(saved)) : []);
  H.set('storeSet', async (k, v) => { saved = JSON.parse(v); return 'ok'; });

  // 1 — reception, not signed in as admin
  H.set('adminAuthed', false);
  ok((await H.get('addPatientNote')('10001', 'Discussed implant, patient wants to think')) === true,
     'reception can write a note');
  ok(saved.length === 1 && saved[0].by === 'reception', 'and it records who wrote it');

  // 3 — the flag
  ok((await H.get('addPatientNote')('10001', 'Ask about the crown shade', { reviewNext: true })) === true,
     'a note can be flagged for the next visit');
  ok(saved[saved.length - 1].reviewNext === true, 'and carries the flag');
  ok(saved[0].reviewNext === false, 'while an ordinary note does not');

  // 2 — striking stays admin-only
  ok((await H.get('strikePatientNote')(saved[0].id, true)) === false,
     'reception cannot strike a note');
  H.set('adminAuthed', true);
  ok((await H.get('strikePatientNote')(saved[0].id, true)) === true, 'admin can');

  // 4 — clearing the flag keeps the note
  const flagged = saved.find(x => x.reviewNext);
  const before = saved.length;
  H.set('renderPatientTimeline', async () => true);
  await H.get('clearNoteReviewFlag')(flagged.id);
  ok(saved.length === before, 'the note is still on the record');
  const after = saved.find(x => x.id === flagged.id);
  ok(!after.reviewNext && after.reviewedAt, 'only the flag went, and when it went is recorded');

  // 3 again, from the source: shown at the top, and to everyone
  const src = fs.readFileSync(FILE, 'utf-8');
  ok(/id="timelineReviewNotes"[\s\S]{0,200}id="timelineAddNoteRow"/.test(src),
     'the banner sits above the note box, at the top of the record');
  ok(/getElementById\('timelineAddNoteRow'\)\.style\.display = 'block';/.test(src),
     'the note box is shown to reception too, not just admin');
  ok(!/if\(!adminAuthed \|\| !currentTimelinePatientId\) return;/.test(src),
     'and the handler no longer refuses reception outright');
  // 5
  ok(/Could not save the note/.test(src), 'a failed save is reported, not swallowed');
  /* Invented CSS renders as nothing and is invisible until someone looks. */
  ok(!/class="notice-banner"/.test(src), 'no class that does not exist in the stylesheet');

  console.log('test_consultation_notes: ' + n + ' assertions OK');
})().catch(e => { console.error(e); process.exit(1); });
