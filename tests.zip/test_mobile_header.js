/* The mobile header carries the icon's colours.
   Rules:
   1. the bar is the icon's warm ink; the wordmark is its gold;
   2. ONLY the bar. The screens below stay on paper — those cards are dense
      with figures read at a glance in a bright surgery, and the cream is
      doing real work there. A dark header is a colour change; a dark app is
      a legibility decision, and nobody asked for that one;
   3. the tagline uses a warm grey mixed for ink, not the paper --muted,
      which goes muddy on a dark bar;
   4. the phone's status bar matches the header, so there is no pale strip
      above a dark band;
   5. the header shows the app's own tile — the same object the home screen
      shows;
   6. the sign-in screen's mark is a real image. It was literally
      src=" + logo + ", a string-concatenation leftover, so that screen
      rendered a broken-image icon. It survived because you sign in once. */
'use strict';
const assert = require('assert');
const fs = require('fs');
let n = 0; const ok = (c, m) => { assert(c, m); n++; };

const src = fs.readFileSync(process.env.MOBILE_FILE || 'index.html', 'utf-8');

// 1
ok(/\.topbar\{[\s\S]{0,400}background:linear-gradient\(180deg, #26211B 0%, #181410 100%\)/.test(src),
   'the bar is the icon\u2019s warm ink');
ok(/color:#A6722E;\s*\n\s*background-image: linear-gradient\(100deg,\s*\n\s*#A6722E/.test(src),
   'the wordmark rests in the icon\u2019s gold');
ok(src.indexOf('#7A3C01') === -1, 'no bronze left over from the cream bar');
/* Reduced motion drops the sweep and paints the wordmark FLAT. That flat
   colour was mixed for cream; left as bronze it sits almost invisible on
   the dark bar — and the people who see it are precisely the people who
   cannot see the sweep that would otherwise carry it. */
ok(/prefers-reduced-motion[\s\S]{0,220}-webkit-text-fill-color:#D9A85C/.test(src),
   'the reduced-motion wordmark is legible on ink');

// 2 — the load-bearing one
ok(/background:var\(--cream\)/.test(src), 'the page body is still paper');
ok(/--cream:#FBF7EF/.test(src), 'and the cream itself is unchanged');
ok(/\.tabbar\{[\s\S]{0,200}background:var\(--white\)/.test(src),
   'the tab bar stays light — it is operated, and dark controls are harder to hit in daylight');
ok(/\.card\{[\s\S]{0,200}background:var\(--white\)/.test(src), 'cards stay white');

// 3 + 4
ok(/color:#A9917A; margin-top:3px;/.test(src), 'the tagline is mixed for ink');
ok(/<meta name="theme-color" content="#26211B">/.test(src), 'the status bar continues the band');

// 5 + 6
ok(/\.brand-badge img\{[\s\S]{0,160}border-radius:11px/.test(src), 'the header mark is the rounded tile');
ok(src.indexOf('src=" + logo + "') === -1, 'the sign-in mark is no longer literal broken markup');
ok(/class="seal-mark"><img src="data:image\/png;base64,iVBOR/.test(src),
   'and is a real image');

console.log('test_mobile_header: ' + n + ' assertions OK');
