/* LOAD SIMULATION — 10k patients / 50k bills / 50k payments / 50k lab cases.
   Audit tool, not a suite test: generates a synthetic clinic at the raw
   layer and times the REAL functions over it. CPU, parse and aggregate
   costs are measured directly; disk is modelled from counted reads
   (reception SSD ≈ 0.2ms/open, admin share ≈ 2200ms/open — the measured
   clinic figure). Changes nothing. */
'use strict';
const { loadApp } = require('./harness/load_app');
const { performance } = require('perf_hooks');
const app = loadApp(process.env.APP_FILE || 'echo-dental-collection-log.html');
const H = app.__hook;

const t = () => performance.now();
const MB = (x) => (x / 1048576).toFixed(1) + ' MB';
const ms = (x) => x >= 1000 ? (x/1000).toFixed(2) + ' s' : x.toFixed(1) + ' ms';
const heap = () => process.memoryUsage().heapUsed;

(async () => {
  // ---------- fake folder at the raw layer ----------
  const disk = new Map();
  let reads = { bill:0, entry:0, labcase:0, index:0, other:0 };
  const readCat = (k) => k.startsWith('bill:') ? 'bill' : k.startsWith('entry:') ? 'entry'
    : k.startsWith('labcase:') ? 'labcase' : k.endsWith('-index') ? 'index' : 'other';
  H.set('folderReady', () => true);
  H.set('_storeGetRaw', async (k) => { reads[readCat(k)]++; return disk.has(k) ? disk.get(k) : null; });
  H.set('_storeSetRaw', async (k, v) => { disk.set(k, v); return 'ok'; });
  H.set('storeListKeys', async (p) => {
    const out = []; for(const k of disk.keys()) if(k.startsWith(p)) out.push(k); return out;
  });
  for(const fn of ['loadingProgressBegin','loadingProgressStep','loadingProgressEnd'])
    H.set(fn, () => null);
  const resetReads = () => { reads = { bill:0, entry:0, labcase:0, index:0, other:0 }; };
  const fc = H.get('fileContentCache');

  // ---------- generation ----------
  const g0 = t(); const h0 = heap();
  const FIRST = ['Aarav','Vivaan','Aditya','Sai','Arjun','Ishaan','Riya','Ananya','Diya','Saanvi','Meera','Kiara','Rohan','Kabir','Zoya','Imran','Fatima','Neha','Pooja','Rahul'];
  const LAST = ['Sharma','Verma','Gupta','Khan','Singh','Yadav','Srivastava','Mishra','Ali','Kapoor','Trivedi','Saxena','Ahmed','Chauhan','Rastogi'];
  const PROCS = ['Root Canal Treatment','Extraction','Tooth Filling','Scaling','Zirconia','Consultation','X-Ray','Retainers'];
  const WORK = ['Crown','Denture','Aligner','Bridge','Inlay'];
  const rand = (() => { let s = 42; return () => (s = (s * 1103515245 + 12345) % 2147483648) / 2147483648; })();
  const pick = (a) => a[Math.floor(rand() * a.length)];

  const NP = 10000, NB = 50000, NL = 50000, DAYS = 1120; // ~3 years, ~45 payments/day
  const pid = (i) => String(10000 + (i % NP));
  const pname = (i) => FIRST[i % FIRST.length] + ' ' + LAST[(i * 7) % LAST.length];
  const dstr = (d) => { const x = new Date(2023, 7, 1); x.setDate(x.getDate() + d);
    return x.getFullYear() + '-' + String(x.getMonth()+1).padStart(2,'0') + '-' + String(x.getDate()).padStart(2,'0'); };

  // bills — ~45/day, 8% cancelled, 3% credit notes
  for(let i = 0; i < NB; i++){
    const day = i % DAYS;
    const items = [];
    const nit = 1 + Math.floor(rand() * 4);
    let sub = 0;
    for(let j = 0; j < nit; j++){
      const amt = Math.round((200 + rand() * 4800));
      sub += amt;
      items.push({ id:'it'+i+'_'+j, category: rand() < 0.3 ? 'pharmacy' : 'procedure',
                   name: pick(PROCS), qty: 1, rate: amt, discPct: 0, amount: amt });
    }
    const b = { billId:'b'+i, billNumber:'EDC/25-26/'+(1000+i), patientId: pid(i), patientName: pname(i),
                date: dstr(day), status:'finalized', items, subtotal: sub, pharmDiscount: 0,
                grandTotal: sub, roundOff: 0, finalizedAt: dstr(day)+'T10:00:00.000Z',
                createdAt: dstr(day)+'T09:00:00.000Z', updatedAt: dstr(day)+'T10:00:00.000Z' };
    if(rand() < 0.08) b.cancellation = { at: dstr(day)+'T18:00:00.000Z', by:'Admin', reason:'entry error' };
    else if(rand() < 0.03){ b.docType = 'credit'; b.items.forEach(it => { it.qty = -1; it.amount = -it.amount; });
      b.subtotal = -b.subtotal; b.grandTotal = -b.grandTotal; }
    disk.set('bill:b'+i, JSON.stringify(b));
  }

  // day entries — 50k payments over DAYS files
  const PER = Math.ceil(50000 / DAYS);
  let payN = 0;
  for(let d = 0; d < DAYS; d++){
    const items = [];
    for(let j = 0; j < PER && payN < 50000; j++, payN++){
      const method = ['cash','upi','upi','card','bank'][Math.floor(rand()*5)];
      const it = { id:'p'+payN, patientId: pid(payN*3), patientName: pname(payN*3),
                   method, amount: Math.round(100 + rand()*3900),
                   time: dstr(d)+'T1'+(j%9)+':0'+(j%6)+':00.000Z', doctorName: 'Dr '+pick(LAST) };
      const r = rand();
      if(r < 0.01) it.method = 'refund';
      else if(r < 0.02) it.method = 'writeoff';
      else if(r < 0.04) it.reversal = { reversedAt: dstr(d + (r < 0.03 ? 0 : 2))+'T19:00:00.000Z', by:'Admin' };
      items.push(it);
    }
    const tt = H.get('computeItemTotals')(items);
    disk.set('entry:'+dstr(d), JSON.stringify({ date: dstr(d), items,
      cash: tt.cash, upi: tt.upi, card: tt.card, bank: tt.bank, updatedAt: dstr(d)+'T20:00:00.000Z' }));
  }

  // lab cases
  for(let i = 0; i < NL; i++){
    const day = i % DAYS;
    const c = { id:'lc'+i, patientId: pid(i*2), patientName: pname(i*2), workType: pick(WORK),
                caseType: rand() < 0.4 ? 'digital' : 'physical', dateLogged: dstr(day),
                createdAt: dstr(day)+'T11:00:00.000Z', updatedAt: dstr(day)+'T11:00:00.000Z' };
    const st = rand();
    if(st > 0.25) c.dateSent = dstr(day);
    if(st > 0.5) c.dateReceived = dstr(Math.min(day+7, DAYS-1));
    if(st > 0.7) c.dateDelivered = dstr(Math.min(day+12, DAYS-1));
    disk.set('labcase:lc'+i, JSON.stringify(c));
  }

  // tasks + directory-ish stubs
  const tasks = [];
  for(let i = 0; i < 3000; i++){
    tasks.push({ id:'t'+i, patientId: pid(i*5), patientName: pname(i*5), status:'advised',
                 procedure: pick(PROCS), nextActionDate: dstr(DAYS - 1 + (i % 200)),
                 createdAt: dstr(i % DAYS)+'T12:00:00.000Z', updatedAt: dstr(i % DAYS)+'T12:00:00.000Z' });
  }
  disk.set('treatment-opportunities', JSON.stringify(tasks));
  const dir = {}; for(let i = 0; i < NP; i++) dir[String(10000+i)] = pname(i);
  H.set('getPatientDirectory', async () => dir);
  H.set('getTaskTriage', async () => ({}));
  H.set('getOrthoPatients', async () => { const o=[]; for(let i=0;i<600;i++) o.push({ patientId: pid(i*11), kind:'ortho' }); return o; });

  let bytes = 0; for(const v of disk.values()) bytes += v.length;
  console.log(`GENERATED  ${NB} bills · ${payN} payments over ${DAYS} days · ${NL} lab cases · ${NP} patients`);
  console.log(`           folder ≈ ${MB(bytes)} raw · gen ${ms(t()-g0)} · heap +${MB(heap()-h0)}\n`);

  const row = (label, dt, extra) => console.log(label.padEnd(46) + ms(dt).padStart(9) + (extra ? '   ' + extra : ''));

  // ---------- BILLS ----------
  resetReads(); let a = t();
  let bills = await H.get('getAllBills')();
  row('bills COLD (per-file, first ever open)', t()-a, `${reads.bill} file reads → admin share ≈ ${(reads.bill*2.2/60).toFixed(0)} min, SSD ≈ ${(reads.bill*0.2/1000).toFixed(1)} s`);
  const bIdxSize = disk.get('bills-index').length;
  H.set('allBillsCache', null); fc.clear(); resetReads(); a = t();
  bills = await H.get('getAllBills')();
  row('bills WARM (index)', t()-a, `1 read of ${MB(bIdxSize)} · ${bills.length} bills`);
  a = t();
  await H.get('saveBill')(JSON.parse(JSON.stringify(bills[100])));
  row('ONE bill save (index patch incl. guard)', t()-a, `index rewritten: ${MB(disk.get('bills-index').length)} each save`);

  // ---------- LAB ----------
  H.set('allLabCasesCache', null); fc.clear(); resetReads(); a = t();
  let cases = await H.get('getAllLabCases')();
  row('lab COLD (per-file, first ever open)', t()-a, `${reads.labcase} file reads → admin ≈ ${(reads.labcase*2.2/60).toFixed(0)} min`);
  const lIdxSize = disk.get('labcases-index').length;
  H.set('allLabCasesCache', null); fc.clear(); resetReads(); a = t();
  cases = await H.get('getAllLabCases')();
  row('lab WARM (index, incl. 50k sort)', t()-a, `1 read of ${MB(lIdxSize)} · ${cases.length} cases`);
  a = t();
  await H.get('storeSet')('labcase:lc123', disk.get('labcase:lc123'));
  row('ONE lab save (funnel index patch)', t()-a, `index rewritten: ${MB(disk.get('labcases-index').length)} each save`);

  // ---------- ENTRIES ----------
  H.set('allEntriesCache', null); fc.clear(); resetReads(); a = t();
  let entries = await H.get('getAllEntries')();
  row('entries COLD (per-day files)', t()-a, `${reads.entry} day reads → admin ≈ ${(reads.entry*2.2/60).toFixed(1)} min`);
  const eIdxSize = disk.get('entries-index') ? disk.get('entries-index').length : 0;
  H.set('allEntriesCache', null); fc.clear(); resetReads(); a = t();
  entries = await H.get('getAllEntries')();
  row('entries WARM (index + today live)', t()-a, `index ${MB(eIdxSize)} · ${entries.length} days`);
  a = t();
  const pastKey = 'entry:' + dstr(10);
  await H.get('storeSet')(pastKey, disk.get(pastKey));
  row('ONE past-day edit (entries index patch)', t()-a, `index rewritten: ${MB(disk.get('entries-index').length)}`);

  // ---------- AGGREGATES the screens actually run ----------
  a = t();
  const pend = await H.get('_perf__computeAllPatientPendingAmounts')();
  row('all patient balances (pending map)', t()-a, `${Object.keys(pend).length} patients`);
  H.set('lastVisitMapCache', null); a = t();
  const seen = await H.get('_buildLastVisitMap')();
  row('last-visit map (Work Pending / To Verify)', t()-a, `${seen.size} patients seen`);
  a = t();
  const rows = await H.get('buildPendingTaskRows')();
  row('Work Pending rows (full build)', t()-a, `${rows.length} rows`);
  a = t();
  const back = H.get('txoBackIn')(tasks, seen, dstr(DAYS-1));
  row('To Verify pass (3k tasks vs visit map)', t()-a, `${back.length} flagged`);

  // month roll-up (Reports)
  a = t();
  const monthEntries = await H.get('getMonthEntries')(2026, 6);
  let tot = 0; monthEntries.forEach(e => { const m = H.get('entryModeTotals')(e); tot += m.cash+m.upi+m.card+m.bank; });
  row('Reports: one month roll-up', t()-a, `${monthEntries.length} days`);

  // search keystroke over 10k directory
  const match = H.get('patientMatchesQuery');
  a = t();
  let hits = 0; for(const [id, nm] of Object.entries(dir)) if(match({ patientId:id, patientName:nm }, 'sha')) hits++;
  row('one search keystroke over 10k patients', t()-a, `${hits} hits`);

  // payments table build for one heavy day (screen path)
  const heavyDay = JSON.parse(disk.get('entry:'+dstr(500)));
  a = t();
  const htmlRows = await H.get('buildPaymentsTableRows')(heavyDay.items, dstr(500), true, true);
  row('payments table for a '+heavyDay.items.length+'-payment day', t()-a, `${MB(htmlRows.length)} of HTML`);

  console.log('\nHEAP after everything: ' + MB(heap()) + ' (caches: parsed bills+entries+cases + raw index strings)');
  console.log('INDEX FILES: bills ' + MB(bIdxSize) + ' · lab ' + MB(lIdxSize) + ' · entries ' + MB(eIdxSize));
})().catch(e => { console.error(e); process.exit(1); });
