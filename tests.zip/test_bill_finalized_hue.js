/* A finalised bill's popup goes green, so draft and issued cannot be
   confused at a glance. Rules:
   1. the class marks the WHOLE editor (the box, not one line), mirroring
      the cancelled treatment that already exists;
   2. a draft never gets it;
   3. a CANCELLED bill never gets it either — it is finalised too, but
      "dead" is the more urgent thing to say, and the two treatments must
      not stack into a muddy green-red box;
   4. the word "Finalised" is shown as well as the colour — colour alone is
      not a label, and it must survive a colour-blind reader;
   5. the status line is innerHTML for the chip's sake, so everything
      user-controlled in it stays escaped. */
'use strict';
const assert = require('assert');
const fs = require('fs');
const { loadApp } = require('./harness/load_app');
const FILE = process.env.APP_FILE || 'echo-dental-collection-log.html';
const app = loadApp(FILE);
const H = app.__hook;
const src = fs.readFileSync(FILE, 'utf-8');
let n = 0; const ok = (c, m) => { assert(c, m); n++; };

const box = app.document.getElementById('billEditorModal');
const render = () => { try{ H.get('renderBillEditor')(); }catch(e){ /* later DOM bits may be absent in the shim */ } };
const has = (c) => box.classList.contains(c);

H.set('billEditorAdminMode', false);
H.set('cachedTodayLockAt', null);

// 2. draft
H.set('currentDraftBill', { billId:'b1', patientId:'10001', patientName:'A', status:'draft',
                            billNumber:'', items:[], grandTotal:0 });
render();
ok(!has('editing-finalized'), 'a draft is not green');
ok(has('editing-draft'), 'a draft turns the whole popup slate grey');

// 1. finalised
H.set('currentDraftBill', { billId:'b1', patientId:'10001', patientName:'A', status:'finalized',
                            billNumber:'EDC/25-26/1001', items:[], grandTotal:500,
                            finalizedAt:'2026-08-24T10:00:00.000Z' });
render();
ok(has('editing-finalized'), 'a finalised bill turns the whole popup green');
ok(!has('editing-draft'), 'and is no longer grey — the three states never stack');

// 3. cancelled wins
H.set('currentDraftBill', { billId:'b1', patientId:'10001', patientName:'A', status:'finalized',
                            billNumber:'EDC/25-26/1001', items:[], grandTotal:500,
                            finalizedAt:'2026-08-24T10:00:00.000Z',
                            cancellation:{ cancelledAt:'2026-08-24T18:00:00.000Z', by:'Admin', reason:'entry error' } });
render();
ok(!has('editing-finalized'), 'a cancelled bill is NOT green — dead beats issued');
ok(!has('editing-draft'), 'nor grey');
ok(has('editing-cancelled'), 'it keeps the cancelled treatment');

// 1 (styling reaches the box, not just a label) + 4 + 5, read from the file
ok(/\.modal-overlay\.editing-finalized \.modal-box\{/.test(src), 'the box itself is tinted');
ok(/\.modal-overlay\.editing-finalized #billEditorPatientLabel\{/.test(src), 'the heading goes green too');
ok(/class="bill-final-chip">Finalised</.test(src), 'the word is shown, not only the colour');
ok(/class="bill-draft-chip">Draft</.test(src), 'a draft says so in words too — it has no bill number to show');
ok(/\.modal-overlay\.editing-draft \.modal-box\{[\s\S]*?border:1px dashed/.test(src),
   'and carries a dashed edge — a signal that survives any colour blindness');
/* Draft is declared FIRST, so on equal specificity the more urgent state
   always paints over it: green over grey, red over both. */
ok(src.indexOf('.modal-overlay.editing-draft .modal-box{')
   < src.indexOf('.modal-overlay.editing-finalized .modal-box{'),
   'draft styling is declared before finalised');
ok(/innerHTML =\s*\n\s*\(currentDraftBill\.status === 'draft'/.test(src)
   && /\+ escapeHtml\(\(currentDraftBill\.billNumber/.test(src),
   'the chips are the only raw HTML — the bill number stays escaped');
/* The cancelled rule must come AFTER the finalised one in the stylesheet,
   or equal specificity would let green win on a cancelled bill. */
ok(src.indexOf('.modal-overlay.editing-cancelled .modal-box{')
   < src.indexOf('.modal-overlay.editing-finalized .modal-box{'),
   'cancelled styling is declared first so nothing depends on it losing');

/* The same-day correction narration is gone — the green popup and the
   "Save Changes" button say it without a sentence. The read-only notice for
   a bill finalised on an EARLIER day stays: without it that editor just
   looks broken. */
ok(src.indexOf('corrections can be made until the end of today') === -1,
   'the same-day narration is gone');
ok(src.indexOf('receptionSameDay') === -1, 'and its now-dead branch with it');
ok(/View only — this bill was finalised on/.test(src),
   'the read-only notice for an earlier day survives');

console.log('test_bill_finalized_hue: ' + n + ' assertions OK');
