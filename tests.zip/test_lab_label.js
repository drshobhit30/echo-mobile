/* The lab stage once called just "Sent" now says "Sent to Lab" everywhere a
   user reads it: the status dropdown, the status meta (pill/groups), a new
   digital case's initial label, the case change log, and the trip fallback.
   Asserts the RULE (the words the screen shows), not line positions. */
'use strict';
const assert = require('assert');
const { loadApp } = require('./harness/load_app');
const app = loadApp(process.env.APP_FILE || 'echo-dental-collection-log.html');
const H = app.__hook;

let n = 0; const ok = (c, msg) => { assert(c, msg); n++; };

const labels = H.get('LAB_STATUS_LABELS');
ok(labels.sent === 'Sent to Lab', 'LAB_STATUS_LABELS.sent reads "Sent to Lab"');
ok(labels.waiting_pickup === 'Waiting Pick-Up' && labels.received === 'Received'
   && labels.delivered === 'Delivered', 'other stages untouched');

// The status meta the pills and stage groups are built from.
const meta = H.get('getLabCaseStatus')({ dateSent: '2026-08-20' });
ok(meta.key === 'sent' && meta.label === 'Sent to Lab', 'status meta label for a sent case');

// The dropdown a case row offers.
const html = H.get('labCaseStatusButtonHtml')({ dateSent: '2026-08-20', caseType: 'digital' });
ok(html.includes('>Sent to Lab<'), 'status dropdown option says Sent to Lab');
ok(!/>Sent</.test(html), 'no bare "Sent" option remains in the dropdown');

console.log('test_lab_label: ' + n + ' assertions OK');
