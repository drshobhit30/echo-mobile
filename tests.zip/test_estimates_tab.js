/* The Estimates tab on the Patient page. Its job is to stop an estimate
   becoming a quiet leak — posted once, then never thought about again.
   Rules:
   1. it lists ONLY estimates still awaiting a decision: not ordinary
      drafts, not estimates that were accepted and billed;
   2. oldest first — the one waiting longest is the one most likely to have
      been forgotten, and it is the reason this list exists;
   3. the tiles state the count and the value, and the value is labelled as
      NOT billed: none of it counts towards any balance;
   4. searching narrows by patient name or id;
   5. a row opens the editor, so it can be edited, reprinted or finalised;
   6. the tab is wired into the sub-tab switcher like the other three. */
'use strict';
const assert = require('assert');
const fs = require('fs');
const { loadApp } = require('./harness/load_app');
const FILE = process.env.APP_FILE || 'echo-dental-collection-log.html';
const app = loadApp(FILE);
const H = app.__hook;
const d = app.document;
let n = 0; const ok = (c, m) => { assert(c, m); n++; };
const eq = (a, b, m) => { assert.strictEqual(a, b, m + ` (got ${a}, want ${b})`); n++; };

const est = (id, name, pid, on, amt, note) => ({ billId:id, patientId:pid, patientName:name,
  status:'draft', date:on, items:[{id:'i'+id,category:'procedure',name:'RCT',qty:1,rate:amt,discPct:0,amount:amt}],
  pharmDiscount:0, subtotal:amt, grandTotal:amt,
  estimate:{ postedAt:on+'T10:00:00.000Z', postedOn:on, note } });

(async () => {
  H.set('folderReady', () => true);
  H.set('todayStr', () => '2026-09-10');
  H.set('getAllBills', async () => [
    est('b1','Aarav Sharma','11111','2026-08-01',24300,'RCT then crowns'),
    est('b2','Neha Gupta','22222','2026-09-09',8000,'Scaling'),
    Object.assign(est('b3','Billed Already','33333','2026-08-05',5000,'x'),
      { status:'finalized', billNumber:'X/1', finalizedAt:'2026-08-06T10:00:00.000Z' }),
    { billId:'b4', patientId:'44444', patientName:'Plain Draft', status:'draft',
      date:'2026-09-10', items:[], pharmDiscount:0, subtotal:0, grandTotal:0 }
  ]);

  await H.get('renderTreatmentEstimatesTab')();
  const html = () => d.getElementById('estList').innerHTML;

  // 1
  eq((html().match(/billing-list-row/g) || []).length, 2, 'two estimates listed');
  ok(html().indexOf('Billed Already') === -1, 'an accepted estimate has left the list');
  ok(html().indexOf('Plain Draft') === -1, 'an ordinary draft was never in it');
  // 2
  ok(html().indexOf('Aarav') < html().indexOf('Neha'), 'oldest first');
  ok(/Given 40 days ago/.test(html()), 'and says how long it has been waiting');
  // 3
  eq(d.getElementById('estStatCount').textContent, '2', 'the count tile');
  ok(d.getElementById('estStatValue').textContent.indexOf('32,300') !== -1, 'the value tile totals them');
  ok(html().indexOf('not billed yet') !== -1, 'each row says the money is not billed');
  // 4
  d.getElementById('estSearchInput').value = 'neha';
  await H.get('renderTreatmentEstimatesTab')();
  eq((html().match(/billing-list-row/g) || []).length, 1, 'search narrows the list');
  ok(html().indexOf('Neha') !== -1, 'to the right patient');
  d.getElementById('estSearchInput').value = 'zzz';
  await H.get('renderTreatmentEstimatesTab')();
  ok(html().indexOf('No estimate matches') !== -1, 'and says so when nothing matches');
  d.getElementById('estSearchInput').value = '';

  // empty state
  H.set('getAllBills', async () => []);
  await H.get('renderTreatmentEstimatesTab')();
  ok(html().indexOf('No treatment estimates are waiting') !== -1, 'empty state reads as calm, not broken');

  // a storage failure must not blank the tab silently
  H.set('getAllBills', async () => { throw new Error('folder gone'); });
  await H.get('renderTreatmentEstimatesTab')();
  ok(html().indexOf('Could not read the bills') !== -1, 'a read failure is reported, not hidden');

  // 5 + 6, from the source
  const src = fs.readFileSync(FILE, 'utf-8');
  ok(/onclick="resumeDraftBill\(/.test(src.slice(src.indexOf('function renderTreatmentEstimatesTab'))),
     'a row opens the editor, not the read-only view');
  ok(/\['search','pending','advance','estimates'\]/.test(src), 'the switcher knows the fourth tab');
  ok(/if\(tab === 'estimates'\) renderTreatmentEstimatesTab\(\);/.test(src), 'and renders it on arrival');
  ok(/id="tlSubTabBtn_estimates"/.test(src) && /id="tlSubTab_estimates"/.test(src),
     'button and pane both exist');
  /* Invented CSS is invisible until someone looks at the screen: every class
     used here must already exist in the stylesheet. */
  const cls = (src.match(/id="tlSubTab_estimates"[\s\S]*?<\/div>\s*\n\s*<div id="tlSubTab_pending"/) || [''])[0];
  /* Only the CARD COLOUR classes: an earlier pattern also matched
     'stat-strip' inside 'money-stat-strip', which is a substring, not a
     class. */
  (cls.match(/compact (stat-[a-z]+)/g) || []).map(x => x.split(' ')[1]).forEach(c => {
    ok(new RegExp('\\.' + c + '\\b').test(src), 'the ' + c + ' card class exists in the stylesheet');
  });

  console.log('test_estimates_tab: ' + n + ' assertions OK');
})().catch(e => { console.error(e); process.exit(1); });
