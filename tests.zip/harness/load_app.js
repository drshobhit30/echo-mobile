/* Loads the desktop app's main script VERBATIM into a Node vm context with a
   permissive DOM, with exactly ONE transform: the top-level `init();` call at
   the end of the script is suppressed, because these tests exercise renderers
   directly with stubbed data rather than booting against a folder. Everything
   under test runs as shipped. __hook (appended AFTER the app source) exposes
   the script's top-level bindings to tests: get(name) reads one, set(name, v)
   reassigns one (function declarations are mutable bindings, so real
   functions can be swapped for stubs and back). */
'use strict';
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const { makeDocument, makeLocalStorage } = require('./dom_shim');

function extractMainScript(htmlPath){
  const html = fs.readFileSync(htmlPath, 'utf-8');
  const re = /<script(?![^>]*type="text\/plain")[^>]*>([\s\S]*?)<\/script>/g;
  let m, best = '';
  while((m = re.exec(html))) if(m[1].length > best.length) best = m[1];
  if(!best) throw new Error('no script found in ' + htmlPath);
  return best;
}

function loadApp(htmlPath){
  let src = extractMainScript(htmlPath);
  const initCall = '\ninit();';
  const at = src.lastIndexOf(initCall);
  if(at === -1) throw new Error('top-level init(); not found — script shape changed, update load_app.js');
  src = src.slice(0, at) + '\n/* harness: top-level init() suppressed */' + src.slice(at + initCall.length);
  src += `
;globalThis.__hook = {
  __v: undefined,
  get(name){ return eval(name); },
  set(name, v){ __hook.__v = v; eval(name + ' = __hook.__v;'); __hook.__v = undefined; }
};`;

  const document = makeDocument();
  const localStorage = makeLocalStorage();
  // Timers are unref'd so the app's standing intervals (clock, refresh
  // countdown, heartbeat) cannot hold a finished test process open.
  const uT = (fn, ms, ...a) => { const t = setTimeout(fn, ms, ...a); if(t.unref) t.unref(); return t; };
  const uI = (fn, ms, ...a) => { const t = setInterval(fn, ms, ...a); if(t.unref) t.unref(); return t; };
  const sandbox = {
    console, setTimeout: uT, clearTimeout, setInterval: uI, clearInterval,
    document, localStorage,
    navigator: { userAgent: 'harness', language: 'en-IN', clipboard: { writeText: async()=>{} } },
    location: { href: 'http://harness/', reload(){ sandbox.__reloads = (sandbox.__reloads||0)+1; } },
    alert(msg){ (sandbox.__alerts = sandbox.__alerts||[]).push(String(msg)); },
    confirm(){ return true; },
    prompt(){ return null; },
    matchMedia(){ return { matches: false, addEventListener(){}, removeEventListener(){}, addListener(){}, removeListener(){} }; },
    requestAnimationFrame(fn){ return uT(()=>fn(Date.now()), 0); },
    cancelAnimationFrame(id){ clearTimeout(id); },
    MutationObserver: class { observe(){} disconnect(){} takeRecords(){ return []; } },
    ResizeObserver: class { observe(){} disconnect(){} },
    indexedDB: { open(){ const r = {}; setTimeout(()=>{ if(r.onerror) r.onerror(new Error('harness: no idb')); }, 0); return r; } },
    fetch: async () => { throw new Error('harness: network disabled'); },
    crypto: require('crypto').webcrypto,
    performance: { now: () => Date.now() },
    Blob: class Blob {}, URL: { createObjectURL(){ return 'blob:harness'; }, revokeObjectURL(){} },
    FileReader: class {},
    screen: { width: 1280, height: 800 },
    getComputedStyle(){ return { getPropertyValue(){ return ''; } }; },
    structuredClone: (x) => JSON.parse(JSON.stringify(x)),
    TextEncoder, TextDecoder,
    btoa: (s) => Buffer.from(s, 'binary').toString('base64'),
    atob: (s) => Buffer.from(s, 'base64').toString('binary'),
  };
  sandbox.addEventListener = () => {};
  sandbox.removeEventListener = () => {};
  sandbox.dispatchEvent = () => true;
  sandbox.window = sandbox;
  sandbox.globalThis = sandbox;
  sandbox.self = sandbox;
  vm.createContext(sandbox);
  vm.runInContext(src, sandbox, { filename: path.basename(htmlPath) + ':main-script' });
  return sandbox;
}

module.exports = { loadApp, extractMainScript };
