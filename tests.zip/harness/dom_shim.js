/* Permissive DOM for headless tests. Per-id element identity: getElementById
   returns THE SAME object for the same id every time, so what a render wrote
   is what the test reads — the property that caught the phantom-folderMsg
   bug in the old harness, kept for the same reason. */
'use strict';

function makeClassList(el){
  const set = new Set();
  return {
    add(...c){ c.forEach(x => x && set.add(x)); },
    remove(...c){ c.forEach(x => set.delete(x)); },
    contains(c){ return set.has(c); },
    toggle(c, force){
      const want = force === undefined ? !set.has(c) : !!force;
      if(want) set.add(c); else set.delete(c);
      return want;
    },
    get value(){ return Array.from(set).join(' '); }
  };
}

function makeElement(id, doc){
  const listeners = {};
  /* innerHTML/textContent are accessors so the browser's escape round-trip
     works: set textContent, read innerHTML, get escaped text — the app's own
     escapeHtml() is built on exactly that. */
  let _html = '', _text = '';
  const esc = (t) => String(t).replace(/&/g,'&amp;').replace(/</g,'&lt;')
    .replace(/>/g,'&gt;').replace(/"/g,'&quot;');
  const el = {
    id: id || '', tagName: 'DIV', style: {}, dataset: {},
    get innerHTML(){ return _html; },
    set innerHTML(v){ _html = String(v); _text = String(v).replace(/<[^>]*>/g, ''); },
    get textContent(){ return _text; },
    set textContent(v){ _text = String(v == null ? '' : v); _html = esc(_text); },
    value: '', checked: false,
    children: [], attributes: {},
    classList: null,
    setAttribute(k, v){ el.attributes[k] = String(v); if(k==='id') el.id = String(v); },
    getAttribute(k){ return (k in el.attributes) ? el.attributes[k] : null; },
    removeAttribute(k){ delete el.attributes[k]; },
    addEventListener(type, fn){ (listeners[type] = listeners[type] || []).push(fn); },
    removeEventListener(type, fn){ if(listeners[type]) listeners[type] = listeners[type].filter(f=>f!==fn); },
    dispatch(type, ev){ (listeners[type]||[]).forEach(fn => fn.call(el, ev || { type, target: el,
      stopPropagation(){}, preventDefault(){} })); },
    click(){ el.dispatch('click'); },
    appendChild(c){ el.children.push(c); return c; },
    removeChild(c){ el.children = el.children.filter(x=>x!==c); return c; },
    querySelector(){ return null; },
    querySelectorAll(){ return []; },
    focus(){}, blur(){}, scrollIntoView(){},
    getBoundingClientRect(){ return { top:0, left:0, width:0, height:0, bottom:0, right:0 }; },
    closest(){ return null; },
    contains(){ return false; },
  };
  el.classList = makeClassList(el);
  return el;
}

function makeDocument(){
  const byId = new Map();
  const docListeners = {};
  const doc = {
    readyState: 'complete',
    visibilityState: 'visible',
    addEventListener(type, fn){ (docListeners[type] = docListeners[type] || []).push(fn); },
    removeEventListener(type, fn){ if(docListeners[type]) docListeners[type] = docListeners[type].filter(f=>f!==fn); },
    __fire(type){ (docListeners[type]||[]).forEach(fn => fn({ type })); },
    getElementById(id){
      if(!byId.has(id)) byId.set(id, makeElement(id, doc));
      return byId.get(id);
    },
    createElement(tag){ const e = makeElement('', doc); e.tagName = String(tag).toUpperCase(); return e; },
    createTextNode(t){ return { textContent: String(t) }; },
    querySelector(){ return null; },
    querySelectorAll(){ return []; },
    body: makeElement('body', null),
    documentElement: makeElement('html', null),
    head: makeElement('head', null),
    title: '',
    __byId: byId,
  };
  return doc;
}

function makeLocalStorage(){
  const m = new Map();
  return {
    getItem(k){ return m.has(k) ? m.get(k) : null; },
    setItem(k, v){ m.set(k, String(v)); },
    removeItem(k){ m.delete(k); },
    clear(){ m.clear(); },
    get length(){ return m.size; },
    key(i){ return Array.from(m.keys())[i] ?? null; },
  };
}

module.exports = { makeDocument, makeElement, makeLocalStorage };
