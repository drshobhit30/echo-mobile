/* The printed bill's section closing row. The rule that matters is not
   cosmetic: THE SECTION ROWS MUST SUM TO THE GRAND TOTAL. A patient holding
   the page adds them up, and a document whose own figures disagree is worse
   than one that never showed them.
   Rules:
   1. every section ends with one total row, inside the table, so the
      payable figure lands under Amount and the discount under Disc %;
   2. procedures' discount is ALREADY inside each item's Amount (it is a
      per-item Disc %), so the row must NOT subtract it again;
   3. pharmacy's discount is a category figure carried by no item row, so
      the row MUST subtract it — the two look identical in the markup and
      mean opposite things, which is how the pharmacy row first printed the
      list price;
   4. with nothing discounted, the row collapses to label + amount: no
      discount cell at all;
   5. "(Before discount)" appears ONCE, in the summary box, and only when a
      discount exists — never per section;
   6. the old floating line outside the table is gone. */
'use strict';
const assert = require('assert');
const { loadApp } = require('./harness/load_app');
const app = loadApp(process.env.APP_FILE || 'echo-dental-collection-log.html');
const H = app.__hook;
let n = 0; const ok = (c, m) => { assert(c, m); n++; };

const rupees = (s) => (s.match(/₹[\d,]+/g) || []).map(x => Number(x.slice(1).replace(/,/g, '')));
const proc = (name, qty, rate, discPct) => ({ id: 'i' + name, category: 'procedure', name, qty, rate, discPct,
  amount: Math.round(qty * rate * (1 - discPct / 100) * 100) / 100 });
const pharm = (name, qty, rate) => ({ id: 'p' + name, category: 'pharmacy', name, qty, rate, amount: qty * rate });
const bill = (items, pharmDiscount) => {
  const subtotal = items.reduce((s, i) => s + i.amount, 0) - (pharmDiscount || 0);
  return { billId: 'b1', billNumber: 'EDC/25-26/1042', patientId: '11111', patientName: 'Sample',
           date: '2026-08-24', status: 'finalized', items, pharmDiscount: pharmDiscount || 0,
           subtotal, grandTotal: subtotal, roundOff: 0, finalizedAt: '2026-08-24T10:00:00.000Z' };
};
const P_D = [proc('RCT', 1, 8000, 10), proc('Crown', 2, 9000, 5), proc('Scaling', 1, 2500, 0)];   // 26,800
const P_N = [proc('RCT', 1, 8000, 0), proc('Crown', 2, 9000, 0), proc('Scaling', 1, 2500, 0)];    // 28,500
const PH = [pharm('Amox', 10, 18), pharm('Rinse', 1, 220)];                                       // 400

const build = H.get('buildBillPageHtml');
const sectionTotals = (html) => {
  const out = [];
  const re = /billpage-total-amt">([^<]+)</g;
  let m; while ((m = re.exec(html))) out.push(rupees(m[1])[0]);
  return out;
};

// The load-bearing check, on all five shapes.
[['procedures only, discounted', bill(P_D, 0)],
 ['nothing discounted', bill(P_N.concat(PH), 0)],
 ['procedure discount only', bill(P_D.concat(PH), 0)],
 ['pharmacy discount only', bill(P_N.concat(PH), 40)],
 ['both discounted', bill(P_D.concat(PH), 40)]].forEach(([name, b]) => {
  const html = build(b);
  const sum = sectionTotals(html).reduce((s, x) => s + x, 0);
  assert.strictEqual(sum, b.grandTotal,
    'section rows must sum to the grand total — ' + name + ' (rows ' + sum + ', bill ' + b.grandTotal + ')');
  n++;
});

// 2 + 3, stated directly
ok(sectionTotals(build(bill(P_D, 0)))[0] === 26800,
   'procedures: the per-item discount is not subtracted twice');
const pharmOnly = sectionTotals(build(bill(P_N.concat(PH), 40)));
ok(pharmOnly[pharmOnly.length - 1] === 360,
   'pharmacy: the category discount IS taken off the section row');

// 1 + 4
const withDisc = build(bill(P_D, 0));
ok(/<tfoot><tr class="billpage-total-row">/.test(withDisc), 'the row lives inside the table');
ok(/billpage-total-disc">− ₹1,700</.test(withDisc), 'the discount prints in its own cell');
const clean = build(bill(P_N, 0));
ok(clean.indexOf('billpage-total-disc') === -1, 'no discount cell when nothing was discounted');
ok(/colspan="4"/.test(clean), 'and the label spans the freed column instead');

// 5
ok(withDisc.indexOf('(Before discount)') !== -1, 'the qualifier appears when there is a discount');
ok(clean.indexOf('(Before discount)') === -1, 'and not when there is none');
ok((withDisc.match(/\(Before discount\)/g) || []).length === 1, 'exactly once, in the summary box');

// 6
ok(withDisc.indexOf('billpage-section-subtotal') === -1,
   'the old floating line outside the table is gone');

/* The qualifier must sit BELOW Net Total, and the printed page must not
   depend on a screen stylesheet for that: the rule lives in the print block
   itself. It first rendered on one line because the stacking rule was
   defined elsewhere in the file. */
const fs = require('fs');
const src = fs.readFileSync(process.env.APP_FILE || 'echo-dental-collection-log.html', 'utf-8');
ok(/\.billpage-summary-row \.label-block\{ display:flex; flex-direction:column;/.test(src),
   'the print CSS stacks the label itself — not borrowed from the screen styles');
ok(/\.billpage-summary-row\.muted \.label-sub\{ font-weight:400/.test(src),
   'and the qualifier is unbolded');

console.log('test_bill_print_section_totals: ' + n + ' assertions OK');
