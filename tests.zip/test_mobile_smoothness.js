/* Mobile responsiveness. Three separate causes of "not smooth", each pinned
   against the REAL functions extracted from the shipped file.

   A. TRAFFIC. The first freshness rule DISCARDED the caches every 90s, so
      every cycle re-downloaded the whole billing history and every past day
      over mobile data. Drive hands back modifiedTime in the same lookup
      that returns the file id, free — so a cycle now asks "changed?" and
      re-reads only when the answer is yes.
   B. RACES. Tap Day, Month, Report quickly and three renders are in the
      air; whichever response landed last used to paint, even if it belonged
      to the first tap. Every render takes a ticket; stale paints are
      dropped.
   C. WASTE. The settings folder was looked up separately by three loaders
      per cycle; a five-second glance at another app reloaded everything. */
'use strict';
const assert = require('assert');
const fs = require('fs');
const vm = require('vm');
let n = 0; const ok = (c, m) => { assert(c, m); n++; };
const eq = (a, b, m) => { assert.strictEqual(a, b, m + ` (got ${a}, want ${b})`); n++; };

const MOB = process.env.MOBILE_FILE || 'index.html';
const src = fs.readFileSync(MOB, 'utf-8');
const grab = (re, what) => { const m = src.match(re); assert(m, 'could not find ' + what); n++; return m[0]; };

// ---- A: run loadBills across three cycles against a mock Drive ----
{
  const bits = [
    grab(/const MONEY_MAX_AGE_MS[\s\S]*?\n\}/, 'freshness rule'),
    grab(/let cachedSettingsFolderId = null;[\s\S]*?\n\}/, 'settings folder cache'),
    grab(/let cachedBills = null;[\s\S]*?\nasync function loadBills\(\)\{[\s\S]*?\n\}\n/, 'loadBills')
  ].join('\n');
  let lookups = 0, reads = 0, modified = '2026-08-24T10:00:00Z';
  const sandbox = {
    console, setTimeout, Promise, Array, Number, Object, JSON, Date,
    driveFolderId: 'root', lastFoundModifiedTime: null,
    driveFindChild: async (parent, name) => {
      lookups++;
      sandbox.lastFoundModifiedTime = (name === 'bills-index.json') ? modified : null;
      return name === 'settings' ? 'sid' : 'fid';
    },
    driveReadJson: async () => { reads++; return { bills: [{ grandTotal: 100 }] }; },
    driveListChildren: async () => []
  };
  vm.createContext(sandbox);
  vm.runInContext(bits + '\nthis.load = loadBills;\nthis.fresh = ensureFreshMoneyData;'
    + '\nthis.setEpoch = (t) => { moneyEpochAt = t; };', sandbox);

  (async () => {
    await sandbox.load();
    eq(reads, 1, 'first load reads the index once');
    const lookupsAfterFirst = lookups;

    // three refresh cycles with an UNCHANGED file
    for(let i = 0; i < 3; i++){ sandbox.fresh(true); await sandbox.load(); }
    eq(reads, 1, 'unchanged file is never re-downloaded, however many cycles');
    ok(lookups > lookupsAfterFirst, 'but it IS re-checked each cycle — freshness is not traded away');
    const cheapChecks = lookups - lookupsAfterFirst;
    ok(cheapChecks <= 6, 'and the check costs a lookup or two, not a download (' + cheapChecks + ')');

    // the desktop writes: modifiedTime moves, so the next cycle re-reads
    modified = '2026-08-24T11:30:00Z';
    sandbox.fresh(true);
    await sandbox.load();
    eq(reads, 2, 'a CHANGED file is re-read — the whole point of revalidating');

    // within the window nothing is checked at all
    const before = lookups;
    sandbox.setEpoch(Date.now());
    ok(sandbox.fresh() === false, 'inside 90s the rule does nothing');
    await sandbox.load();
    eq(lookups, before, 'and a tap costs no Drive traffic at all');

    // ---- B: the generation guard ----
    const guard = grab(/let renderGen = 0;\nfunction paintAllowed\(token\)\{[\s\S]*?\n\}/, 'paint guard');
    const s2 = { console };
    vm.createContext(s2);
    vm.runInContext(guard + '\nthis.take = () => ++renderGen;\nthis.allowed = paintAllowed;', s2);
    const first = s2.take();
    const second = s2.take();
    ok(!s2.allowed(first), 'a paint from the older render is refused');
    ok(s2.allowed(second), 'the newest render paints');

    // every view threads the token through to its paint
    for(const fn of ['renderDayView', 'renderMonthView', 'renderPatientView', 'renderReportView']){
      ok(new RegExp('async function ' + fn + '\\(token\\)').test(src), fn + ' takes a render token');
    }
    eq((src.match(/if\(token !== undefined && !paintAllowed\(token\)\) return;/g) || []).length, 8,
       'and every paint site checks it before touching the DOM');

    // ---- C: waste ----
    eq((src.match(/driveFindChild\(driveFolderId, 'settings', true\)/g) || []).length, 1,
       'the settings folder is looked up in one place only');
    ok(/getSettingsFolderId\(\)/.test(src), 'and reused from cache by every loader');
    ok(/if\(\(Date\.now\(\) - moneyEpochAt\) < MONEY_MAX_AGE_MS\) return;[\s\S]{0,120}ensureFreshMoneyData\(true\);/.test(src),
       'a brief glance at another app does not reload everything');
    ok(/await Promise\.all\(\[loadDayEntry\(currentDate, token\), renderDayBills\(currentDate, token\)\]\)/.test(src),
       'the Day view loads its two halves together, not one after the other');
    ok(/if\(from === to \|\| _reducedMotion\(\)/.test(src),
       'figures animate only when they actually change — already true, kept true');

    console.log('test_mobile_smoothness: ' + n + ' assertions OK');
  })().catch(e => { console.error(e); process.exit(1); });
}
