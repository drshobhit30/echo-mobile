/* "One patient, one open task", enforced in the SAVE, not in the popup.

   THE REAL CASE: patient 11111 held three open 'scaling' tasks created
   within 61 seconds — three rows in the list, three people ready to ring
   the same patient about the same tooth. The rule existed, but it lived in
   the Add Task popup, so it only governed tasks created there. Two routes
   went around it: closing a task and creating the next in one action, and a
   second tab whose popup checked a list read before the first tab saved.
   Rules:
   1. duplicates collapse on save, whatever route created them;
   2. the OLDEST open task survives — it is the one that has been waiting;
   3. nothing typed is lost: notes and activity move into the survivor;
   4. the soonest chase date wins;
   5. other patients are untouched, and closed/struck tasks are untouched —
      this is only about how many are OPEN at once;
   6. a legitimate single task saves unchanged. */
'use strict';
const assert = require('assert');
const { loadApp } = require('./harness/load_app');
const app = loadApp(process.env.APP_FILE || 'echo-dental-collection-log.html');
const H = app.__hook;
let n = 0; const ok = (c, m) => { assert(c, m); n++; };
const eq = (a, b, m) => { assert.strictEqual(a, b, m + ` (got ${a}, want ${b})`); n++; };

H.set('folderReady', () => true);
H.set('invalidatePendingTaskCaches', () => {});
let written = null;
H.set('storeSet', async (k, v) => { written = JSON.parse(v); return 'ok'; });

const task = (id, at, pid, proc, extra) => Object.assign({
  id, patientId: pid, patientName: 'P' + pid, kind: 'opportunity', procedure: proc,
  status: 'advised', createdAt: at, nextActionDate: '2026-09-03',
  activity: [{ at, text: 'created' }] }, extra || {});

(async () => {
  // 1–4: the real case, three tasks 61 seconds apart
  await H.get('saveTreatmentOpportunities')([
    task('a', '2026-08-20T12:07:20.000Z', '11111', 'scaling'),
    task('b', '2026-08-20T12:07:43.000Z', '11111', 'scaling', { nextActionDate: '2026-09-01' }),
    task('c', '2026-08-20T12:08:08.000Z', '11111', 'polishing'),
    task('z', '2026-08-20T12:00:00.000Z', '22222', 'filling')
  ]);
  const mine = written.filter(o => o.patientId === '11111');
  eq(mine.length, 1, 'three become one');
  eq(mine[0].id, 'a', 'the oldest survives — the one that has been waiting');
  ok(mine[0].activity.length >= 3, 'every task\u2019s notes moved into it');
  ok(/merged into this one/.test(JSON.stringify(mine[0].activity)),
     'and the merge is recorded, not silent');
  ok(mine[0].procedure.indexOf('polishing') !== -1,
     'a different procedure is carried across, not discarded');
  eq(mine[0].nextActionDate, '2026-09-01', 'the soonest chase date wins');

  // 5
  eq(written.filter(o => o.patientId === '22222').length, 1, 'another patient is untouched');

  const closed = task('done', '2026-08-01T10:00:00.000Z', '33333', 'crown',
    { status: 'accepted', closedAt: '2026-08-02T10:00:00.000Z', closeReason: 'attended' });
  await H.get('saveTreatmentOpportunities')([
    closed, task('open1', '2026-08-20T10:00:00.000Z', '33333', 'scaling')
  ]);
  eq(written.filter(o => o.patientId === '33333').length, 2,
     'a closed task and an open one coexist — only OPEN ones are limited');

  // 6
  await H.get('saveTreatmentOpportunities')([task('solo', '2026-08-20T10:00:00.000Z', '44444', 'RCT')]);
  eq(written.length, 1, 'an ordinary single task saves unchanged');
  eq(written[0].id, 'solo', 'and is not rewritten');

  console.log('test_task_duplicate_guard: ' + n + ' assertions OK');
})().catch(e => { console.error(e); process.exit(1); });
