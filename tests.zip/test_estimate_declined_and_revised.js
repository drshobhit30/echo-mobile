/* Two follow-ons to the treatment estimate.

   A. DECLINED. The patient thought about it and said no. That is a fact
      worth keeping — it answers "did we ever offer this?" next year and
      stops the same conversation happening twice. So the record is struck,
      not erased: it leaves the chase lists, stays in the history, and can
      be revived if they change their mind.
      THE TRAP: "declined" was first written so that a declined estimate
      stopped counting as an estimate — which quietly took it out of the
      overnight sweep's exemption, so the sweep would have DELETED it the
      next morning. Declining must not be a slow delete.
   B. REVISED. If an estimate is edited after a copy was printed, the
      patient is holding a sheet that no longer matches and neither party
      can tell by looking. The next printed copy says so. */
'use strict';
const assert = require('assert');
const { loadApp } = require('./harness/load_app');
const app = loadApp(process.env.APP_FILE || 'echo-dental-collection-log.html');
const H = app.__hook;
let n = 0; const ok = (c, m) => { assert(c, m); n++; };

const est = (extra) => Object.assign({
  billId: 'b1', patientId: '10001', patientName: 'Sample', status: 'draft', date: '2026-08-01',
  items: [{ id:'P1', category:'procedure', name:'RCT', qty:1, rate:5000, discPct:0, amount:5000 }],
  pharmDiscount: 0, subtotal: 5000, grandTotal: 5000,
  estimate: { postedAt:'2026-08-01T10:00:00.000Z', postedOn:'2026-08-01', note:'RCT on 26' }
}, extra || {});

(async () => {
  H.set('folderReady', () => true);
  H.set('todayStr', () => '2026-08-25');

  // ---- A: the state rules
  const live = est();
  const declined = est({ billId:'b2' });
  declined.estimate.declinedAt = '2026-08-20T10:00:00.000Z';
  declined.estimate.declinedOn = '2026-08-20';
  declined.estimate.declineReason = 'cost';

  ok(H.get('isTreatmentEstimate')(live), 'a live estimate is awaiting a decision');
  ok(!H.get('isTreatmentEstimate')(declined), 'a declined one is not — it leaves the chase lists');
  ok(H.get('estimateDeclined')(declined), 'and is recognised as declined');
  ok(H.get('wasTreatmentEstimate')(declined), 'while still being an estimate for history');

  // THE TRAP: the sweep must spare it
  const deleted = [];
  H.set('storeDelete', async (k) => { deleted.push(k); return 'ok'; });
  H.set('updateBillsIndex', async () => true);
  /* The sweep also logs and refreshes; stubbed so a genuine failure stands
     out instead of hiding inside a stack trace from the shim. */
  H.set('addBillLogEntry', async () => true);
  H.set('renderBillingDrafts', async () => true);
  H.set('renderBillingStatsCards', async () => true);
  H.set('currentDraftBill', null);
  const plainStale = { billId:'b9', patientId:'x', patientName:'x', status:'draft',
                       date:'2026-08-01', items:[], pharmDiscount:0, subtotal:0, grandTotal:0 };
  await H.get('autoDiscardStaleDrafts')([live, declined, plainStale]);
  ok(deleted.indexOf('bill:b9') !== -1, 'an ordinary stale draft is still swept');
  ok(deleted.indexOf('bill:b1') === -1, 'the live estimate survives');
  ok(deleted.indexOf('bill:b2') === -1,
     'and so does the DECLINED one — declining is not a slow delete');

  // it still opens, so a change of mind does not mean retyping
  ok(/resumeDraftBill/.test(H.get('billRowOpenAction')(declined)),
     'a declined estimate still opens in the editor');

  // ---- B: revision
  const printed = est({ billId:'b3' });
  printed.estimate.printedAt = '2026-08-01T11:00:00.000Z';
  H.get('stampEstimateRevision')(printed);
  ok(printed.estimate.revisedOn === '2026-08-25', 'editing a PRINTED estimate stamps a revision');

  const neverPrinted = est({ billId:'b4' });
  H.get('stampEstimateRevision')(neverPrinted);
  ok(!neverPrinted.estimate.revisedOn,
     'editing one that was never printed does not — nobody is holding a stale copy');

  const sheet = H.get('buildBillPageHtml')(printed);
  ok(sheet.indexOf('REVISED') !== -1, 'the printed sheet says REVISED in the number line');
  ok(sheet.indexOf('replaces any earlier copy') !== -1, 'and says plainly what that means');
  const cleanSheet = H.get('buildBillPageHtml')(est({ billId:'b5' }));
  ok(cleanSheet.indexOf('REVISED') === -1, 'an unrevised estimate says nothing about revisions');

  console.log('test_estimate_declined_and_revised: ' + n + ' assertions OK');
})().catch(e => { console.error(e); process.exit(1); });
