/* Mobile money-freshness. THE MISMATCH THIS PINS: today's day file was
   fetched fresh every render while bills and the entries index were latched
   once per session — so a payment made at the desk appeared on the phone
   while its bill did not, balances went low or negative, and Refresh
   "fixed" it. Nothing was wrong with the data, only with mixing two ages
   of it.
   Rules:
   1. before any view renders, money caches older than 90s are dropped
      TOGETHER — bills and entries share one age, always;
   2. within 90s nothing is dropped: active tapping must not turn into a
      Drive call per tap;
   3. force (the Refresh button) drops them regardless of age;
   4. returning to the foreground reloads — a phone back from the pocket has
      been asleep, not watching — and the handler stays inert on the sign-in
      screen;
   5. the service worker cache is bumped so phones actually receive this. */
'use strict';
const assert = require('assert');
const fs = require('fs');
const path = require('path');
const vm = require('vm');
let n = 0; const ok = (c, m) => { assert(c, m); n++; };

const MOB = process.env.MOBILE_FILE || 'index.html';
const SW = process.env.SW_FILE || path.join(path.dirname(MOB), 'sw.js');
const src = fs.readFileSync(MOB, 'utf-8');

// ---- 1–3, run for real: the function extracted and driven in a sandbox ----
const fnMatch = src.match(/const MONEY_MAX_AGE_MS = [\s\S]*?function ensureFreshMoneyData\(force\)\{[\s\S]*?\n\}/);
ok(!!fnMatch, 'the freshness rule exists');
/* The rule now marks data for REVALIDATION rather than discarding it: the
   discard version re-downloaded the whole history every 90s over mobile
   data. The property being pinned is unchanged — bills and entries always
   share one age — but it is now expressed as two flags flipping together,
   with the actual re-read decided by modifiedTime (test_mobile_smoothness). */
const sandbox = { Date, billsRevalidate: false, entriesRevalidate: false };
vm.createContext(sandbox);
vm.runInContext(fnMatch[0] + '\nthis.run = ensureFreshMoneyData;'
  + '\nthis.setEpoch = (t)=>{ moneyEpochAt = t; };'
  + '\nthis.state = () => ({ bills: billsRevalidate, idx: entriesRevalidate });'
  /* `let` inside a vm script is script-scoped, not a context property, so
     assigning sandbox.billsRevalidate from the test would silently do
     nothing and the assertion below would read a stale true. */
  + '\nthis.reset = () => { billsRevalidate = false; entriesRevalidate = false; };', sandbox);

sandbox.setEpoch(Date.now() - 91 * 1000);
ok(sandbox.run() === true, 'older than 90s → dropped');
let st = sandbox.state();
ok(st.bills === true && st.idx === true,
   'and BOTH are marked together — one age for all money');

sandbox.reset();   // via the script, not context properties — see above
ok(sandbox.run() === false, 'within 90s → untouched');
st = sandbox.state();
ok(st.bills === false && st.idx === false, 'no revalidation, so no Drive call per tap');
ok(sandbox.run(true) === true, 'force drops them regardless of age');

// ---- wiring, from the source ----
ok(/async function renderCurrentView\(\)\{\s*\n\s*ensureFreshMoneyData\(\);/.test(src),
   'every view render passes through the rule — the single choke point');
ok(/visibilitychange[\s\S]{0,200}visibilityState !== 'visible'\) return;[\s\S]{0,220}ensureFreshMoneyData\(true\);\s*\n\s*loadEverything\(\);/.test(src),
   'returning to the foreground forces a fresh look');
ok(/mainScreen'\)\.classList\.contains\('hidden'\)\) return;/.test(src),
   'but not on the sign-in screen');
ok(/refreshBtn[\s\S]{0,400}ensureFreshMoneyData\(true\);/.test(src),
   'the Refresh button uses the same rule, forced');
ok(/billsRevalidate = true;\s*\n\s*entriesRevalidate = true;/.test(src),
   'the rule marks both, in one place');

// ---- 5
ok(/CACHE_VERSION = 'echo-nexus-v25'/.test(fs.readFileSync(SW, 'utf-8')),
   'service worker bumped to v15 so phones receive this');

console.log('test_mobile_freshness: ' + n + ' assertions OK');
