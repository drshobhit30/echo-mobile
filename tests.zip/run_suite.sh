#!/bin/bash
# Echo Nexus test suite.
# Run from ANY directory:   bash tests/run_suite.sh
# It locates the app files itself and refuses to guess: if a file is not
# where it says, it stops and names it, rather than quietly testing a stale
# copy that happens to share the name (which is exactly what the old
# cwd-relative defaults once did).
#
#   APP_FILE     desktop app          default: <suite-root>/echo-dental-collection-log.html
#   MOBILE_FILE  mobile companion     default: <suite-root>/index.html
#   SW_FILE      service worker       default: alongside MOBILE_FILE
#
# EXPECTED-FAIL: four tests pin features rolled back on 24 Aug 2026 and are
# kept failing on purpose. They are reported, never fatal — and an
# UNEXPECTED PASS is called out loudly, because it means the build contains
# a feature it is not supposed to.
set -u
cd "$(dirname "$0")/.."
ROOT="$(pwd)"
export APP_FILE="${APP_FILE:-$ROOT/echo-dental-collection-log.html}"
export MOBILE_FILE="${MOBILE_FILE:-$ROOT/index.html}"
export SW_FILE="${SW_FILE:-$(dirname "$MOBILE_FILE")/sw.js}"

for f in "$APP_FILE" "$MOBILE_FILE" "$SW_FILE"; do
  if [ ! -f "$f" ]; then
    echo "MISSING FILE: $f"
    echo "Set APP_FILE / MOBILE_FILE / SW_FILE to the real locations and re-run."
    exit 1
  fi
done
echo "desktop : $APP_FILE"
echo "mobile  : $MOBILE_FILE"
echo "sw      : $SW_FILE"
echo

echo "— syntax —"
node -e "
const fs=require('fs');
for(const f of [process.env.APP_FILE, process.env.MOBILE_FILE]){
  const h=fs.readFileSync(f,'utf-8');
  const re=/<script(?![^>]*type=\"text\/plain\")[^>]*>([\s\S]*?)<\/script>/g;
  let m,i=0; while((m=re.exec(h))){ new (require('vm').Script)(m[1], {filename:f+':script'+(i++)}); }
  console.log(f,'—',i,'script block(s) parse');
}
new (require('vm').Script)(fs.readFileSync(process.env.SW_FILE,'utf-8'),{filename:'sw.js'});
console.log('sw.js parses');
" || exit 1
echo

EXPECTED_FAIL=""
is_expected_fail(){ case " $EXPECTED_FAIL " in *" $1 "*) return 0;; *) return 1;; esac; }

pass=0; fail=0; xfail=0; xpass=0; failed_names=""
for t in tests/test_*.js; do
  name="$(basename "$t" .js)"
  out="$(timeout 180 node "$t" 2>&1)"; code=$?
  if [ $code -eq 0 ]; then
    if is_expected_fail "$name"; then
      xpass=$((xpass+1))
      echo "!! UNEXPECTED PASS  $name — this feature was rolled back; why is it present?"
    else
      pass=$((pass+1)); echo "ok   $name — $(echo "$out" | tail -1)"
    fi
  else
    if is_expected_fail "$name"; then
      xfail=$((xfail+1))
      echo "xf   $name — expected-fail (feature rolled back 24 Aug 2026)"
    else
      fail=$((fail+1)); failed_names="$failed_names $name"
      echo "FAIL $name"
      echo "$out" | head -6 | sed 's/^/     /'
    fi
  fi
done

echo
echo "passed $pass · failed $fail · expected-fail $xfail · unexpected-pass $xpass"
if [ $fail -gt 0 ]; then echo "FAILING:$failed_names"; exit 1; fi
if [ $xpass -gt 0 ]; then echo "Investigate the unexpected pass(es) above."; exit 1; fi
echo "SUITE GREEN (expected-fails reported, not counted)"
