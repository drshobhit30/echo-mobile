/* M2 fix pinned: the login card warns while Admin is still on the shipped
   default password, and only then. Rules:
   1. stored record = default → the note shows (real PBKDF2 path, no stub);
   2. stored record = anything else → the note stays hidden;
   3. successfully changing the password hides the note in the same breath;
   4. the note never prints the default itself. */
'use strict';
const assert = require('assert');
const fs = require('fs');
const { loadApp } = require('./harness/load_app');
const FILE = process.env.APP_FILE || 'echo-dental-collection-log.html';
const app = loadApp(FILE);
const H = app.__hook;
const doc = app.document;
let n = 0; const ok = (c, m) => { assert(c, m); n++; };

(async () => {
  H.set('folderReady', () => true);
  const DEF = H.get('DEFAULT_ADMIN_PASSWORD');
  const make = H.get('makeAdminPasswordRecord');

  // Rule 1 — still on the default.
  let stored = await make(DEF);
  H.set('_storeGetRaw', async (k) => k === 'admin-password' ? stored : null);
  H.set('_storeSetRaw', async () => 'ok');            // upgrade write lands nowhere real
  await H.get('updateDefaultPasswordNotice')();
  const note = doc.getElementById('adminDefaultPwNote');
  ok(note.style.display === 'block', 'note shows while the default is in force');
  ok(!note.textContent.includes(DEF) && !fs.readFileSync(FILE,'utf-8')
       .split('adminDefaultPwNote')[1].slice(0,400).includes(DEF),
     'the note never prints the default itself');

  // Rule 2 — a changed password.
  stored = await make('Something#Else9');
  H.get('fileContentCache').delete('admin-password'); // simulate a fresh session's first read
  H.set('defaultPwStillInUse', null);
  await H.get('updateDefaultPasswordNotice')();
  ok(note.style.display === 'none', 'note hidden once the password differs');

  // Rule 3 — the change flow itself clears it, live.
  stored = await make(DEF);
  H.get('fileContentCache').delete('admin-password');
  H.set('defaultPwStillInUse', null);
  await H.get('updateDefaultPasswordNotice')();
  ok(note.style.display === 'block', 'back on default for the change test');
  doc.getElementById('curPassInput').value = DEF;
  doc.getElementById('newPassInput').value = 'Fresh#Pass7';
  doc.getElementById('confirmPassInput').value = 'Fresh#Pass7';
  await H.get('changeAdminPassword')();
  ok(/updated successfully/i.test(doc.getElementById('passChangeMsg').textContent),
     'change succeeded');
  ok(note.style.display === 'none' && H.get('defaultPwStillInUse') === false,
     'a successful change hides the note in the same breath');

  console.log('test_default_pw_notice: ' + n + ' assertions OK');
})().catch(e => { console.error(e); process.exit(1); });
