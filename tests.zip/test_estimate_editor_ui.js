/* What the editor SHOWS for an estimate. Its own file, on a fresh app
   instance: the estimate behaviour test stubs renderBillEditor for its
   navigation checks, and asserting a render that never ran is a test that
   passes while the screen is wrong.
   Rules:
   1. an estimate hides the pharmacy half of the editor;
   2. and the Pharmacy Discount row, which lives in the TOTALS block rather
      than inside that section — hiding the section left an input offering
      to discount medicines on a document that cannot contain any;
   3. an ordinary draft still shows both, laid out exactly as before. */
'use strict';
const assert = require('assert');
const { loadApp } = require('./harness/load_app');
const app = loadApp(process.env.APP_FILE || 'echo-dental-collection-log.html');
const H = app.__hook;
const d = app.document;
let n = 0; const ok = (c, m) => { assert(c, m); n++; };
const eq = (a, b, m) => { assert.strictEqual(a, b, m + ` (got ${a}, want ${b})`); n++; };

H.set('folderReady', () => true);
H.set('todayStr', () => '2026-08-24');
H.set('cachedTodayLockAt', null);
H.set('billEditorAdminMode', false);

const bill = (extra) => Object.assign({ billId:'b1', patientId:'10001', patientName:'S', status:'draft',
  date:'2026-08-24', pharmDiscount:0, subtotal:5000, grandTotal:5000,
  items:[{ id:'P1', category:'procedure', name:'RCT', qty:1, rate:5000, discPct:0, amount:5000 }] }, extra || {});
const show = (id) => { const el = d.getElementById(id); return el ? (el.style.display || 'shown') : 'MISSING'; };
const render = () => { try{ H.get('renderBillEditor')(); }catch(e){ /* later DOM bits absent in the shim */ } };

// A render that silently did nothing would make every check below pass.
H.set('currentDraftBill', bill());
render();
ok(show('billPharmacySection') !== 'MISSING', 'the editor really rendered');

// 1 + 2
H.set('currentDraftBill', bill({ estimate:{ postedAt:'2026-08-24T10:00:00.000Z', postedOn:'2026-08-24', note:'RCT' } }));
render();
eq(show('billPharmacySection'), 'none', 'an estimate hides the pharmacy half');
eq(show('billPharmDiscountRow'), 'none', 'and the Pharmacy Discount row with it');

/* The discard control stays — an estimate must be removable when the
   patient says no — but it says what it removes. "Discard Draft" reads as
   throwing away unfinished typing; what is actually thrown away is a
   proposal the patient holds a printed copy of. */
eq(d.getElementById('billDiscardDraftBtn').style.display, 'inline-flex',
   'an estimate can still be discarded');
ok(d.getElementById('billDiscardDraftBtn').textContent.indexOf('Discard Estimate') !== -1,
   'and the button says Estimate, not Draft');

// 3
H.set('currentDraftBill', bill());
render();
ok(show('billPharmacySection') !== 'none', 'an ordinary draft still shows the pharmacy half');
eq(show('billPharmDiscountRow'), 'flex', 'and its discount row, laid out as before');
ok(d.getElementById('billDiscardDraftBtn').textContent.indexOf('Discard Draft') !== -1,
   'while an ordinary draft still reads Discard Draft');

console.log('test_estimate_editor_ui: ' + n + ' assertions OK');
