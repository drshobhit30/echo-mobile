/* Work Pending (né "Pending Task Creation") now counts BOTH kinds of pending
   work: patients with no task yet, and postponed tasks whose patient has been
   in since (the To Verify set). Screen-level: the real renderers run against
   stubbed data builders, and what is asserted is what the elements SAY.
   Rules pinned:
   1. Tasks-page tile = creation rows + verify rows; summary line splits them
      so tile and card stay checkable against each other;
   2. zero creation rows + some verify rows does NOT read "Nothing waiting";
   3. Home lane figure agrees, and its name chips include verify patients;
   4. all three on-screen labels say "Work Pending";
   5. verify computation failing (builder throws) degrades to the old figure
      rather than taking the page down. */
'use strict';
const assert = require('assert');
const fs = require('fs');
const { loadApp } = require('./harness/load_app');
const FILE = process.env.APP_FILE || 'echo-dental-collection-log.html';
const app = loadApp(FILE);
const H = app.__hook;
const doc = app.document;
let n = 0; const ok = (c, m) => { assert(c, m); n++; };

(async () => {
  // ---- labels on screen (rule 4) ------------------------------------------
  const html = fs.readFileSync(FILE, 'utf-8');
  ok(html.includes('<span class="home-lane-title">Work Pending</span>'), 'home lane says Work Pending');
  ok(html.includes('<div class="home-stat-label">Work Pending</div>'), 'tasks tile says Work Pending');
  ok(html.includes('\u23f3 Work Pending</h3>'), 'section heading says Work Pending');
  ok(!html.includes('<span class="home-lane-title">Pending Task Creation</span>')
     && !html.includes('<div class="home-stat-label">Pending Task Creation</div>')
     && !html.includes('Pending Task Creation</h3>'), 'no user-facing label still says Pending Task Creation');

  // ---- shared stubs --------------------------------------------------------
  H.set('animateStatNumber', (el, target) => { if(el) el.textContent = String(target); });
  H.set('folderReady', () => true);
  H.set('findFarDatedTasks', async () => []);
  H.set('getTreatmentOpportunities', async () => []);
  H.set('buildLastVisitMap', async () => new Map());

  const creationRow = (id, name) => ({
    patientId: id, patientName: name, lastDate: '2026-08-20', lastWhat: 'payment recorded',
    ortho: false, onHold: false, ongoing: false
  });
  const verifyEntry = (id, name) => ({
    task: { id: 't-' + id, patientId: id, patientName: name },
    visit: { date: '2026-08-23', what: 'payment' }, held: false
  });

  // ---- Tasks page: 1 creation + 2 verify (rule 1) --------------------------
  H.set('buildPendingTaskRows', async () => [creationRow('10001', 'Asha')]);
  H.set('txoBackIn', () => [verifyEntry('10002', 'Bilal'), verifyEntry('10003', 'Chitra')]);
  await H.get('renderPendingTasksPage')();
  ok(doc.getElementById('txoStatPending').textContent === '3',
     'tile counts creation + verify (1 + 2 = 3)');
  const sum1 = doc.getElementById('pendingSummary').textContent;
  ok(/1 patient waiting for a decision/.test(sum1), 'summary names the creation half');
  ok(/2 postponed tasks to verify/.test(sum1), 'summary names the verify half');
  ok(doc.getElementById('pendingList').innerHTML.includes('Asha'), 'creation row rendered');

  // ---- Tasks page: 0 creation + 2 verify (rule 2) --------------------------
  H.set('buildPendingTaskRows', async () => []);
  await H.get('renderPendingTasksPage')();
  ok(doc.getElementById('txoStatPending').textContent === '2', 'tile shows verify-only count');
  const sum2 = doc.getElementById('pendingSummary').textContent;
  ok(!/Nothing waiting — every patient seen has a task/.test(sum2),
     'does NOT claim nothing is waiting while tasks sit on verify');
  ok(/2 postponed tasks to verify/.test(sum2), 'summary still says what the figure is');

  // ---- Tasks page: 0 + 0 keeps the honest all-clear ------------------------
  H.set('txoBackIn', () => []);
  await H.get('renderPendingTasksPage')();
  ok(doc.getElementById('txoStatPending').textContent === '0', 'all clear counts zero');
  ok(/Nothing waiting/.test(doc.getElementById('pendingSummary').textContent),
     'all clear still says so plainly');

  // ---- Home lane (rule 3) --------------------------------------------------
  H.set('buildPendingTaskRows', async () => [creationRow('10001', 'Asha')]);
  H.set('txoBackIn', () => [verifyEntry('10002', 'Bilal')]);
  await H.get('renderHomePendingCard')();
  ok(doc.getElementById('homePendingCount').textContent === '2', 'home figure = 1 creation + 1 verify');
  ok(/need a decision/.test(doc.getElementById('homePendingLabel').textContent), 'home label plural');
  const names = doc.getElementById('homePendingNames').innerHTML;
  ok(names.includes('Asha') && names.includes('Bilal'), 'home chips include the verify patient');

  // ---- degradation (rule 5) ------------------------------------------------
  H.set('getTreatmentOpportunities', async () => { throw new Error('folder gone'); });
  H.set('txoBackIn', () => { throw new Error('should not be reached'); });
  await H.get('renderPendingTasksPage')();
  ok(doc.getElementById('txoStatPending').textContent === '1',
     'verify failing degrades to the creation-only figure, page still renders');

  console.log('test_work_pending: ' + n + ' assertions OK');
})().catch(e => { console.error(e); process.exit(1); });
