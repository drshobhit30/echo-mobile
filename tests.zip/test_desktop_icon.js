/* The desktop file's icons.
   Rules:
   1. the FAVICON is the simplified tooth, not the detailed mark: a browser
      tab renders at 16px, where the web collapses into speckle;
   2. it carries the phone's palette (warm ink, gold gradient) so the two
      products read as one family;
   3. the INSTALL icon is the full artwork, because that one renders large;
   4. THE PRINTED LOGO IS UNTOUCHED — it prints on white paper, and a dark
      tile there would put an ink-soaked square on every bill a patient is
      handed. This is the assertion that matters most in this file. */
'use strict';
const assert = require('assert');
const fs = require('fs');
let n = 0; const ok = (c, m) => { assert(c, m); n++; };

const d = fs.readFileSync(process.env.APP_FILE || 'echo-dental-collection-log.html', 'utf-8');
/* Slice to the closing quote of the tag, not to the first '>' — the SVG
   contains angle brackets of its own, and slicing on '>' cut the colours
   out of the string being tested. The favicon is percent-encoded partly so
   this cannot happen again. */
const favStart = d.indexOf('<link rel="icon"');
const fav = d.slice(favStart, d.indexOf('">', d.indexOf('%3C/svg%3E', favStart)) + 2);

// 1 + 2
ok(/rel="icon" type="image\/svg\+xml"/.test(fav), 'the favicon is still an inline SVG');
ok(fav.indexOf('%2326211B') !== -1 && fav.indexOf('%23181410') !== -1,
   'tile uses the warm ink of the phone icon');
ok(fav.indexOf('%23E2B877') !== -1 && fav.indexOf('%23A6722E') !== -1,
   'tooth uses the same gold gradient');
ok(fav.indexOf('%23C08F42') === -1, 'the old bronze tile is gone');
ok(fav.indexOf('M16 6c-5.3') !== -1, 'the simplified tooth path is retained');
ok(fav.length < 1500, 'and it stays small — a favicon is fetched on every load');
ok(fav.indexOf('%3Csvg') !== -1 && fav.indexOf('<svg') === -1,
   'angle brackets are percent-encoded, so the tag cannot be truncated by a naive parse');

// 3
const apple = d.slice(d.indexOf('<link rel="apple-touch-icon"'),
                      d.indexOf('>', d.indexOf('<link rel="apple-touch-icon"')) + 1);
ok(/data:image\/png;base64,iVBOR/.test(apple), 'the install icon is a PNG');
ok(apple.length > 20000, 'and is the full-resolution artwork, not the tab icon');

// 4 — the one that protects a patient-facing document
const logo = d.slice(d.indexOf('id="printLogoSource"'), d.indexOf('</div>', d.indexOf('id="printLogoSource"')));
ok(logo.indexOf('iVBORw0KGgo') !== -1, 'the printed-bill logo is still its own PNG');
ok(logo.indexOf('26211B') === -1 && logo.indexOf('181410') === -1,
   'and carries none of the dark tile — bills print bronze on white');
ok(d.indexOf('printLogoSource') !== -1 && (d.match(/printLogoSource/g) || []).length >= 3,
   'and is still wired to the bill and report builders');

console.log('test_desktop_icon: ' + n + ' assertions OK');
