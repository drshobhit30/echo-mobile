/* The bonus finding from this pass, closed and pinned: restore writes bills
   through storeSet directly (never saveBill), so an IN-PLACE restore over a
   matching bill set left bills-index serving PRE-restore money after the
   reload. Rules:
   1. the trap is real: without the read-and-acknowledge line, writing '{}'
      over a differing index gets three-way-MERGED straight back — the stale
      index resurrects itself (this is why restore seeds _lastSeenRaw first);
   2. with the seed, the reset lands, every matcher rejects a version-less
      '{}', and the next getAllBills rebuilds from the restored files —
      counted reads prove it came from disk, not the old index;
   3. both reset calls sit in the restore flow (static). */
'use strict';
const assert = require('assert');
const fs = require('fs');
const { loadApp } = require('./harness/load_app');
const FILE = process.env.APP_FILE || 'echo-dental-collection-log.html';
const app = loadApp(FILE);
const H = app.__hook;
let n = 0; const ok = (c, m) => { assert(c, m); n++; };
const eq = (a, b, m) => { assert.strictEqual(a, b, m + ` (got ${a}, want ${b})`); n++; };

(async () => {
  const disk = new Map();
  const readLog = [];
  H.set('folderReady', () => true);
  H.set('_storeGetRaw', async (k) => { readLog.push(k); return disk.has(k) ? disk.get(k) : null; });
  H.set('_storeSetRaw', async (k, v) => { disk.set(k, v); return 'ok'; });
  H.set('storeListKeys', async (p) =>
    Array.from(disk.keys()).filter(k => k.startsWith(p) && !k.endsWith('-index')));

  // The world after an in-place restore: file has the RESTORED figure,
  // the index still carries the PRE-restore one, key sets matching.
  disk.set('bill:b1', JSON.stringify({ billId:'b1', patientId:'10001', status:'finalized',
                                       grandTotal: 700, date:'2026-08-01' }));   // restored truth
  const staleIndex = JSON.stringify({ v: 1, builtAt: 'old',
    keys: ['bill:b1'],
    bills: [{ billId:'b1', patientId:'10001', status:'finalized', grandTotal: 9999, date:'2026-08-01' }] });
  disk.set('bills-index', staleIndex);

  // Rule 1 — the trap, demonstrated: a naive '{}' write gets merged back.
  H.get('_lastSeenRaw').delete('bills-index');
  H.get('fileContentCache').delete('bills-index');
  await H.get('storeSet')('bills-index', '{}');
  ok(disk.get('bills-index') !== '{}' && /9999/.test(disk.get('bills-index')),
     'TRAP: without the acknowledge line, the stale index merges itself back');

  // Rule 2 — the restore recipe: read-and-acknowledge, then reset.
  H.get('_lastSeenRaw').set('bills-index', await H.get('_storeGetRaw')('bills-index'));
  await H.get('storeSet')('bills-index', '{}');
  eq(disk.get('bills-index'), '{}', 'with the seed, the reset lands');

  H.set('allBillsCache', null);
  H.get('fileContentCache').delete('bills-index');
  H.get('fileContentCache').delete('bill:b1');
  readLog.length = 0;
  const bills = await H.get('getAllBills')();
  eq(bills.length, 1, 'one bill');
  eq(bills[0].grandTotal, 700, 'the RESTORED figure is served — 9999 is gone for good');
  ok(readLog.includes('bill:b1'), 'and it provably came from the restored file, not the index');

  // Rule 3 — wired into the restore flow itself.
  const src = fs.readFileSync(FILE, 'utf-8');
  ok(/await resetDerivedIndex\('bills-index'\);\s*\n\s*await resetDerivedIndex\('labcases-index'\);/.test(src),
     'restore resets both non-funnelled indexes');

  console.log('test_restore_index_reset: ' + n + ' assertions OK');
})().catch(e => { console.error(e); process.exit(1); });
