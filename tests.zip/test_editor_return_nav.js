/* Closing the bill editor puts you back where you opened it from.
   The editor lives inside the Billing tab, so opening one from anywhere
   else must switch tabs to show it — which meant closing it left you on
   Billing, on a screen you never asked for. Reading a patient's record,
   opening their estimate and closing it should return you to that
   patient's record, on the sub-tab you were using.
   Rules:
   1. opened from the patient page → closing returns to the patient page,
      re-opens that patient, and restores the sub-tab;
   2. opened from Billing → closing navigates nowhere at all;
   3. the return is cleared after use, so a later close cannot fling you
      somewhere stale;
   4. the sub-tab is tracked in a real variable, not guessed. */
'use strict';
const assert = require('assert');
const fs = require('fs');
const { loadApp } = require('./harness/load_app');
const FILE = process.env.APP_FILE || 'echo-dental-collection-log.html';
const app = loadApp(FILE);
const H = app.__hook;
let n = 0; const ok = (c, m) => { assert(c, m); n++; };

(async () => {
  const nav = [];
  H.set('folderReady', () => true);
  H.set('getBill', async () => ({ billId:'b1', patientId:'11111', patientName:'S', status:'draft',
    date:'2026-08-01', items:[], pharmDiscount:0, subtotal:0, grandTotal:0,
    estimate:{ postedAt:'2026-08-01T10:00:00.000Z', postedOn:'2026-08-01', note:'x' } }));
  H.set('renderBillEditor', () => {});
  H.set('refreshBillingLists', () => {});
  H.set('openPatientTimeline', async (pid) => { nav.push('patient:' + pid); });
  H.set('switchTimelineSubTab', (t) => { nav.push('subTab:' + t); });
  H.set('switchReceptionTab', async (t) => { nav.push('tab:' + t); H.set('currentReceptionTab', t); });
  const settle = () => new Promise(r => setTimeout(r, 20));

  // 1
  H.set('currentReceptionTab', 'patientdb');
  H.set('currentTimelineSubTab', 'estimates');
  H.set('currentTimelinePatientId', '11111');
  await H.get('resumeDraftBill')('b1');
  nav.length = 0;
  H.get('closeBillEditor')();
  await settle();
  ok(nav.indexOf('tab:patientdb') !== -1, 'closing returns to the patient page');
  ok(nav.indexOf('patient:11111') !== -1, 'with the same patient open');
  ok(nav.indexOf('subTab:estimates') !== -1, 'on the sub-tab you were using');

  // 3
  nav.length = 0;
  H.get('closeBillEditor')();
  await settle();
  ok(nav.length === 0, 'a second close navigates nowhere — the return was consumed');

  // 2
  H.set('currentReceptionTab', 'billing');
  await H.get('resumeDraftBill')('b1');
  nav.length = 0;
  H.get('closeBillEditor')();
  await settle();
  ok(nav.length === 0, 'opened from Billing, closing moves you nowhere');

  // 4
  const src = fs.readFileSync(FILE, 'utf-8');
  ok(/let currentTimelineSubTab = 'search';/.test(src), 'the sub-tab is a real variable');
  ok(/function switchTimelineSubTab\(tab\)\{\s*\n\s*currentTimelineSubTab = tab;/.test(src),
     'and every switch records it');
  ok(!/typeof currentTimelineSubTab === 'string'/.test(src),
     'not read through a typeof guard that would silently always be null');

  console.log('test_editor_return_nav: ' + n + ' assertions OK');
})().catch(e => { console.error(e); process.exit(1); });
