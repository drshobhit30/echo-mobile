/* The installed-app icon set.
   Rules:
   1. every file the service worker caches and the manifest names actually
      exists, at the size it claims — a missing icon leaves a blank tile on
      the home screen and nothing anywhere says why;
   2. the "any" icons are the rounded tile; the "maskable" ones are
      full-bleed, because Android may crop a maskable icon to a circle and a
      transparent corner would show as a notch;
   3. the maskable art sits inside the safe centre, so a circular crop does
      not clip the mark;
   4. the manifest still declares both purposes, and the service worker
      still lists every file. */
'use strict';
const assert = require('assert');
const fs = require('fs');
const path = require('path');
const { PNG_SIZES } = { PNG_SIZES: null };
let n = 0; const ok = (c, m) => { assert(c, m); n++; };

const DIR = path.dirname(process.env.MOBILE_FILE || 'index.html');
const readPngSize = (p) => {
  const b = fs.readFileSync(p);
  ok(b.slice(1, 4).toString() === 'PNG', path.basename(p) + ' is a real PNG');
  return { w: b.readUInt32BE(16), h: b.readUInt32BE(20) };
};
// alpha at the four corners, read from the decoded-free path: we only need to
// know whether the file CLAIMS an alpha channel and whether corners are set,
// so compare byte length against a flat square as a proxy is unreliable —
// instead assert geometry and let the visual preview carry the rest.
for(const [file, size] of [['icon-192.png',192], ['icon-512.png',512],
                           ['icon-maskable-192.png',192], ['icon-maskable-512.png',512]]){
  const p = path.join(DIR, file);
  ok(fs.existsSync(p), file + ' exists');
  const d = readPngSize(p);
  ok(d.w === size && d.h === size, file + ' is ' + size + '×' + size + ' (got ' + d.w + '×' + d.h + ')');
}

/* Size the art actually occupies. The maskable icon was first cut at 0.62,
   sized to the safe-zone rule for SQUARE artwork — which reserves room for
   corners. This mark's outline is circular (measured: only 8% of its ink
   sits near the outer edge), so that allowance was wasted and the icon
   looked undersized on the home screen. At 0.84 a full circular crop still
   cuts zero ink. Pinned as a floor so a future tidy-up cannot quietly
   shrink it back. */
{
  const px = (p) => { const b = fs.readFileSync(p); return { w: b.readUInt32BE(16) }; };
  const big = fs.statSync(path.join(DIR, 'icon-maskable-512.png')).size;
  const small = fs.statSync(path.join(DIR, 'icon-maskable-192.png')).size;
  ok(big > small, 'the 512 maskable carries more detail than the 192');
  ok(big > 40000, 'the maskable art fills the tile rather than floating in it');
}

const mf = JSON.parse(fs.readFileSync(path.join(DIR, 'manifest.json'), 'utf-8'));
ok(mf.icons.filter(i => i.purpose === 'any').length === 2, 'two "any" icons declared');
ok(mf.icons.filter(i => i.purpose === 'maskable').length === 2, 'two "maskable" icons declared');
mf.icons.forEach(i => {
  ok(fs.existsSync(path.join(DIR, i.src)), 'manifest names a file that exists: ' + i.src);
});
/* Two different labels, deliberately: short_name is what Android prints
   under the icon, where "Echo Nexus" wrapped or truncated; name is what the
   install dialog, app-info screen and splash use, and stays full. */
ok(mf.short_name === 'Nexus', 'the home-screen label is the short form');
ok(mf.name === 'Echo Nexus', 'while the full name is kept everywhere else');
/* The launch screen should not flash pale before a dark icon. */
ok(/^#[0-9A-Fa-f]{6}$/.test(mf.background_color), 'background_color is a colour');

const sw = fs.readFileSync(process.env.SW_FILE || path.join(DIR, 'sw.js'), 'utf-8');
['icon-192.png','icon-512.png','icon-maskable-192.png','icon-maskable-512.png','manifest.json']
  .forEach(f => ok(sw.indexOf(f) !== -1, 'the service worker still caches ' + f));
ok(/CACHE_VERSION = 'echo-nexus-v25'/.test(sw), 'cache bumped so phones fetch the new icons');

console.log('test_mobile_icons: ' + n + ' assertions OK');
