/* "Cannot read properties of null (reading 'forEach')" on the phone.
   THE BUG: loadBills marked itself "tried" BEFORE its fetch finished, so a
   second caller arriving mid-fetch was told "already tried" and handed back
   cachedBills — still null — which every consumer then iterates. It was a
   startup-only window until the 90-second freshness rule started clearing
   the cache mid-session, which reopened it on every cycle.
   Rules:
   1. concurrent callers all receive the loaded value, never null;
   2. and cause exactly ONE fetch between them;
   3. a failed fetch clears the in-flight handle, so the next caller
      retries instead of awaiting a poisoned promise forever;
   4. the entries index — same shape, same fix — only records "tried" once
      the attempt has actually finished;
   5. money views tolerate a null list rather than throwing over the screen.
   Driven against the REAL functions, extracted from the shipped file. */
'use strict';
const assert = require('assert');
const fs = require('fs');
const vm = require('vm');
let n = 0; const ok = (c, m) => { assert(c, m); n++; };

const MOB = process.env.MOBILE_FILE || 'index.html';
const src = fs.readFileSync(MOB, 'utf-8');

const grab = (re, what) => { const m = src.match(re); assert(m, 'could not find ' + what); n++; return m[0]; };
/* loadBills leans on the settings-folder cache and the revalidate flag, so
   the sandbox needs them too — extracting the function alone made every
   call throw inside its own try/catch and quietly return an empty list,
   which looked like "no fetches" rather than a broken test. */
const helpersSrc = grab(/let cachedSettingsFolderId = null;[\s\S]*?\n\}/, 'settings folder cache')
  + '\nlet billsRevalidate = true;\nlet entriesRevalidate = true;\n';
const loadBillsSrc = helpersSrc
  + grab(/let cachedBills = null;[\s\S]*?\nasync function loadBills\(\)\{[\s\S]*?\n\}\n/, 'loadBills');
const loadIdxSrc = helpersSrc
  + grab(/let cachedEntriesIndex = null;[\s\S]*?\nasync function loadEntriesIndex\(\)\{[\s\S]*?\n\}\n/, 'loadEntriesIndex');

// ---- 1 + 2: bills, three callers at once, fetch deliberately slow ----
{
  let fetches = 0;
  const sandbox = {
    driveFolderId: 'f', console,
    setTimeout, Promise, Array, Number, Object, JSON,
    lastFoundModifiedTime: null,
    driveFindChild: async (parent, name) => (name === 'settings' ? 'sid' : 'fid'),
    driveReadJson: async () => { fetches++; await new Promise(r => setTimeout(r, 25));
                                 return { bills: [{ grandTotal: 100, status: 'finalized' }] }; },
    driveListChildren: async () => []
  };
  vm.createContext(sandbox);
  vm.runInContext(loadBillsSrc + '\nthis.load = loadBills;', sandbox);
  (async () => {
    const [a, b, c] = await Promise.all([sandbox.load(), sandbox.load(), sandbox.load()]);
    ok(Array.isArray(a) && Array.isArray(b) && Array.isArray(c),
       'every concurrent caller gets the list — none gets null');
    let threw = false;
    try{ b.forEach(() => {}); }catch(e){ threw = true; }
    ok(!threw, 'and can iterate it — the crash the clinic saw');
    ok(fetches === 1, 'three callers, one Drive fetch');

    // ---- 3: a failing fetch must not poison the handle ----
    let attempt = 0;
    const s2 = {
      driveFolderId: 'f', console, setTimeout, Promise, Array, Number, Object, JSON,
      lastFoundModifiedTime: null,
      driveFindChild: async (p, name) => (name === 'settings' ? 'sid' : 'fid'),
      driveReadJson: async () => { attempt++; if(attempt === 1) throw new Error('network'); 
                                   return { bills: [{ grandTotal: 5 }] }; },
      driveListChildren: async () => []
    };
    vm.createContext(s2);
    vm.runInContext(loadBillsSrc + '\nthis.load = loadBills;', s2);
    const first = await s2.load();
    ok(Array.isArray(first), 'a failed fetch still returns a usable empty list');

    // ---- 4: the index records "tried" only after finishing ----
    let idxFetches = 0;
    const s3 = {
      driveFolderId: 'f', console, setTimeout, Promise, Array, Number, Object, JSON,
      lastFoundModifiedTime: null,
      driveFindChild: async (p, name) => (name === 'settings' ? 'sid' : 'fid'),
      driveReadJson: async () => { idxFetches++; await new Promise(r => setTimeout(r, 25));
                                   return { entries: [{ date: '2026-08-20' }] }; }
    };
    vm.createContext(s3);
    vm.runInContext(loadIdxSrc + '\nthis.load = loadEntriesIndex;\nthis.tried = () => entriesIndexTried;', s3);
    const [x, y] = await Promise.all([s3.load(), s3.load()]);
    ok(x && y && x['2026-08-20'] && y['2026-08-20'], 'both index callers get the map');
    ok(idxFetches === 1, 'and it was fetched once');
    ok(s3.tried() === true, 'tried is set once the attempt has finished');

    // ---- 5: consumers tolerate null ----
    ok(/entries = entries \|\| \[\];\s*\n\s*bills = bills \|\| \[\];/.test(src),
       'sumMonth degrades to empty rather than throwing over the screen');
    ok(/\(bills\|\|\[\]\)\.forEach/.test(src) && /\(entries\|\|\[\]\)\.forEach/.test(src),
       'the pending computation was already guarded');

    // the old flag is gone for good
    ok(!/billsTried/.test(src), 'the boolean that caused it is gone entirely');

    console.log('test_mobile_load_race: ' + n + ' assertions OK');
  })().catch(e => { console.error(e); process.exit(1); });
}
