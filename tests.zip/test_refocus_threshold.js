/* Perf #2 pinned: a short flick-away no longer pays the refocus re-read set;
   a real absence still does; and Close Day freshness is threshold-EXEMPT.
   Rules:
   1. refocus after a sub-threshold absence keeps every volatile cache —
      entries, lab cases, bills, both indexes, the listings;
   2. day-locks is forgotten on EVERY refocus regardless (H1 must not
      regress behind the optimisation built on top of it);
   3. refocus after a beyond-threshold absence clears the full set, exactly
      as before;
   4. the threshold is a named constant with the trade-off written beside it. */
'use strict';
const assert = require('assert');
const fs = require('fs');
const { loadApp } = require('./harness/load_app');
const FILE = process.env.APP_FILE || 'echo-dental-collection-log.html';
const app = loadApp(FILE);
const H = app.__hook;
const doc = app.document;
let n = 0; const ok = (c, m) => { assert(c, m); n++; };

const fill = () => {
  const fc = H.get('fileContentCache');
  ['entry:2026-08-20','labcase:a','bill:b1','bills-index','labcases-index','entries-index','day-locks']
    .forEach(k => fc.set(k, 'CACHED'));
};
const have = (k) => H.get('fileContentCache').has(k);

// 1 + 2: short flick
fill();
H.set('refocusHiddenAt', Date.now() - 3000);   // hidden 3s ago
doc.__fire('visibilitychange');                 // visibilityState is 'visible'
ok(have('entry:2026-08-20') && have('labcase:a') && have('bill:b1'), 'volatile caches survive a flick');
ok(have('bills-index') && have('labcases-index') && have('entries-index'), 'indexes survive too');
ok(!have('day-locks'), 'day-locks is forgotten even on a flick — Close Day never lags (H1 exempt)');

// 3: real absence
fill();
H.set('refocusHiddenAt', Date.now() - (H.get('REFOCUS_TRUST_MS') + 5000));
doc.__fire('visibilitychange');
ok(!have('entry:2026-08-20') && !have('labcase:a') && !have('bill:b1'),
   'a real absence clears the volatile set exactly as before');
ok(!have('bills-index') && !have('labcases-index') && !have('day-locks'),
   'and the indexes and the lock go with it');

// the hidden edge records the moment
doc.visibilityState = 'hidden';
const before = H.get('refocusHiddenAt');
doc.__fire('visibilitychange');
ok(H.get('refocusHiddenAt') > before, 'going hidden stamps the moment the absence began');
doc.visibilityState = 'visible';

// 4: the constant, named and explained
const src = fs.readFileSync(FILE, 'utf-8');
ok(/const REFOCUS_TRUST_MS = 15000;/.test(src), 'threshold is a named 15s constant');
ok(/FOR THE SCREEN\s+ONLY/.test(src) && /write path re-checks fresh/.test(src),
   'the trade-off is written beside it, not implied');

console.log('test_refocus_threshold: ' + n + ' assertions OK');
