/* Mobile: rolling figures, colour, and the tab surviving a refresh.
   Read as TEXT, like the collapse test: booting the phone page needs
   Google's SDKs, so what is pinned here is the wiring, which is where
   these three could silently rot.
   Rules:
   1. every money figure on the page goes through rollMoney/rollCount —
      a raw textContent = fmtINR(...) left behind is a figure that snaps
      while its neighbours roll, which looks broken rather than plain;
   2. the roller carries its three guards: cancel a roll already running
      (two animations on one element flicker), instant-set when the value
      is unchanged (an idle refresh must not re-animate the screen), and
      instant-set with no requestAnimationFrame or reduced motion — the
      number being RIGHT never depends on the animation;
   3. the last value is kept on the element, never parsed back out of the
      text — formatted rupees do not parse;
   4. the open tab is saved on every switch and restored BEFORE the first
      render, and an unknown saved value falls through to the default;
   5. all four payment modes carry a real colour, and the figure inherits
      it rather than each mode needing its own rule. */
'use strict';
const assert = require('assert');
const fs = require('fs');
const html = fs.readFileSync(process.env.MOBILE_FILE || 'index.html', 'utf-8');
let n = 0; const ok = (c, m) => { assert(c, m); n++; };

// 1
const rawMoney = html.match(/getElementById\('[A-Za-z]+'\)\.textContent\s*=\s*fmtINR/g) || [];
ok(rawMoney.length === 0, 'no money figure snaps: ' + rawMoney.length + ' raw writes left');
['monthTotal','monthBilled','monthCollected','monthCash','monthUpi','monthCard','monthBank',
 'pendingTotal','pendingOrtho','pendingRegular','totalAmount','modeCash','modeUpi','modeCard','modeBank']
  .forEach(id => ok(html.indexOf("rollMoney('" + id + "'") !== -1, id + ' rolls'));
['dayBillCount','payCount'].forEach(id =>
  ok(html.indexOf("rollCount('" + id + "'") !== -1, id + ' counts up'));

// 2
ok(/cancelAnimationFrame\(el\.__rollRAF\)/.test(html), 'a second render cancels the roll in flight');
ok(/from === to \|\| _reducedMotion\(\) \|\| typeof requestAnimationFrame !== 'function'/.test(html),
   'unchanged value, reduced motion, or no rAF → set instantly');
ok(/el\.textContent = fmt\(to\);\s*\/\/ exact/.test(html), 'the final frame prints the exact value');

// 3
ok(/el\.__rollVal = to;/.test(html) && !/parseFloat\(el\.textContent/.test(html),
   'last value kept on the element, not parsed back out of formatted rupees');

// 4
ok(/localStorage\.setItem\(VIEW_KEY, view\)/.test(html), 'the open tab is saved on every switch');
ok(/KNOWN_VIEWS\.indexOf\(_savedView\) !== -1/.test(html), 'an unknown saved tab is ignored');
/* Asserted against the STATE DECLARATION, not against wherever boot is
   called: the restore must sit at `let currentView`, so no ordering of
   init() can outrun it. */
const restoreAt = html.indexOf('localStorage.getItem(VIEW_KEY)');
ok(restoreAt !== -1 && restoreAt < html.indexOf('function switchView'),
   'the tab is restored at the state declaration, before anything can render');
ok(/let currentView = 'day';\s*\ntry\{/.test(html),
   'restore sits immediately on the state, not beside the tab buttons');

// 5
['cash','upi','card','bank'].forEach(m => {
  const re = new RegExp('\\.mode-chip\\.' + m + '\\{[^}]*background:#');
  ok(re.test(html), m + ' tile is tinted, not just hairlined');
});
ok(/\.mode-chip \.m-amt\{ color:currentColor; \}/.test(html),
   'the figure inherits its tile colour — one rule covers all four');

/* 6. The loading overlay, ported from the desktop: it BLURS the screen
      you are on rather than replacing it, it is held off briefly so quick
      renders never flash it, and hiding cancels a pending appearance (or a
      fast render is followed by an overlay for work that already finished).
      Reduced motion keeps the overlay and drops the spinning. */
ok(/backdrop-filter:blur\(4px\); -webkit-backdrop-filter:blur\(4px\);/.test(html),
   'the overlay blurs the live screen, with the webkit prefix iOS needs');
ok(/\.loading-overlay\{[^}]*position:fixed; inset:0/.test(html), 'it covers the page');
ok(/\.loading-overlay\.visible\{ opacity:1/.test(html) && /transition:opacity 0\.15s ease/.test(html),
   'it fades rather than snapping in');
/* The mark must be the CLINIC's own — the same image the desktop shows —
   and EMBEDDED, so it is there before sign-in and offline. Pinned against
   the desktop file itself, so the two apps can never drift apart. */
const desk = fs.readFileSync(process.env.APP_FILE || 'echo-dental-collection-log.html', 'utf-8');
const deskLogo = (desk.match(/id="printLogoSource"[^>]*>\s*<img[^>]*src="(data:image\/[^"]+)"/) || [])[1];
ok(!!deskLogo, 'the desktop clinic mark was found to compare against');
ok(html.indexOf('loading-overlay-badge') !== -1, 'the mark sits inside the sweeping ring');
ok(deskLogo && html.indexOf(deskLogo) !== -1,
   'mobile shows the SAME clinic mark as the desktop, byte for byte');
ok(!/loading-overlay-logo"><img src="icon-192\.png"/.test(html),
   'not the PWA app icon — one clinic, one mark');
ok(/if\(_loadingTimer\)\{ clearTimeout\(_loadingTimer\); _loadingTimer = null; \}/.test(html),
   'hiding cancels an overlay that has not appeared yet');
ok(/if\(!on\)\{ el\.classList\.remove\('visible'\); return; \}/.test(html),
   'hiding is immediate, never deferred');
ok(/const LOADING_DELAY_MS = 280;/.test(html), 'quick renders show nothing at all');
ok(!/style\.opacity = on \? '0\.35'/.test(html),
   'the old page-dimming is gone \u2014 blur says it without making text unreadable');
ok(/@media \(prefers-reduced-motion: reduce\)\{\s*\.loading-overlay-badge::before\{ animation:none/.test(html),
   'reduced motion keeps the overlay and drops the spin');

console.log('test_mobile_polish: ' + n + ' assertions OK');
