/* READ-ONLY AUDIT PROBE (this session's audit — verifies, changes nothing).
   Runs the shipped money functions on crafted shapes and checks the doctrine:
   voided=nothing; refund subtracts cash; write-off in no bucket; unknown
   method folds into cash; same-day reversal out of day totals, later-day
   reversal stays; entry totals never shrink below stored; bill rounding
   mirrors on credit notes; pharmacy discount reverses with its sale;
   pending = billed − payments with cancelled bills and reversed payments
   out and refunds handed back. Also REPRODUCES the visit-map gap: a
   cancelled-bill-only visit is invisible to the pending/verify machinery. */
'use strict';
const assert = require('assert');
const { loadApp } = require('./harness/load_app');
const app = loadApp(process.env.APP_FILE || 'echo-dental-collection-log.html');
const H = app.__hook;
let n = 0; const ok = (c, m) => { assert(c, m); n++; };
const eq = (a, b, m) => { assert.strictEqual(a, b, m + ` (got ${a}, want ${b})`); n++; };

(async () => {
  const T = H.get('computeItemTotals');
  // 1. mode doctrine
  let t = T([
    { method:'cash', amount:500 }, { method:'upi', amount:300 },
    { method:'card', amount:200 }, { method:'bank', amount:100 },
  ]);
  eq(t.overall, 1100, 'plain modes sum');
  t = T([{ method:'cash', amount:500 }, { method:'refund', amount:200 }]);
  eq(t.cash, 300, 'refund subtracts from cash');
  t = T([{ method:'cash', amount:500 }, { method:'writeoff', amount:400 }]);
  eq(t.overall, 500, 'write-off sits in no bucket');
  t = T([{ method:'cash', amount:500, voided:true }]);
  eq(t.overall, 0, 'voided counts as nothing');
  t = T([{ method:'gpay', amount:250 }]);
  eq(t.cash, 250, 'unknown method folds into cash, never vanishes');

  // 2. reversal day rule
  const R = H.get('reversalExcludesFromDayTotals');
  const sameDay = { time:'2026-08-20T10:00:00.000Z', reversal:{ reversedAt:'2026-08-20T15:00:00.000Z' } };
  const laterDay = { time:'2026-08-20T10:00:00.000Z', reversal:{ reversedAt:'2026-08-22T09:00:00.000Z' } };
  ok(R(sameDay) === true, 'same-day reversal leaves the day total');
  ok(R(laterDay) === false, 'later-day reversal stays in its own day');
  t = T([{ method:'cash', amount:500 }, Object.assign({ method:'upi', amount:300 }, sameDay)]);
  eq(t.overall, 500, 'day total drops the same-day reversal');

  // 3. entry totals never shrink below stored fields
  const EMT = H.get('entryModeTotals');
  let e = { cash:1000, upi:0, card:0, bank:0, items:[{ method:'cash', amount:400 }] };
  eq(EMT(e).cash, 1000, 'unrecognised-shape day cannot shrink');
  e = { cash:400, upi:0, card:0, bank:0,
        items:[{ method:'cash', amount:400 }, { method:'upi', amount:300 }] };
  eq(EMT(e).upi, 300, 'fuller items win when they account for more');

  // 4. bill math: rounding mirror + pharmacy discount on credit notes
  const RB = H.get('recomputeBillTotals');
  const sale = { items:[{ category:'procedure', amount:1250.5 }], pharmDiscount:0 };
  RB(sale);
  eq(sale.grandTotal, 1251, 'sale rounds half away from zero');
  const cn = { items:[{ category:'procedure', amount:-1250.5 }], pharmDiscount:0 };
  RB(cn);
  eq(cn.grandTotal, -1251, 'credit note mirrors exactly — no stranded rupee');
  eq(sale.grandTotal + cn.grandTotal, 0, 'sale + CN net to zero');
  const cnPharm = { items:[{ category:'pharmacy', amount:-500 }], pharmDiscount:200 };
  RB(cnPharm);
  eq(cnPharm.pharmDiscount, -200, 'CN discount carries the sign of its lines');
  eq(cnPharm.grandTotal, -300, 'discounted sale refunded at the DISCOUNTED price');
  // identity Net − Disc ± RoundOff = Grand across shapes
  for(const b of [sale, cn, cnPharm]){
    eq(H.get('round2')(b.subtotal - b.pharmDiscount + b.roundOff), b.grandTotal,
       'identity subtotal−disc+roundOff=grand');
  }
  // negative rate rejected AT BOTH EDITOR DOORS (add line, edit line). The
  // model helper is internal; the doors are what a user can reach. Screen
  // test: fill the inputs, run the shipped handler, read the message.
  H.set('currentDraftBill', { billId:'d1', status:'draft', items:[], pharmDiscount:0,
                              date:'2026-08-24', patientId:'10001' });
  H.set('canEditItems', () => true);
  const doc = app.document;
  doc.getElementById('nmX').value = 'Filling';
  doc.getElementById('qtX').value = '2';
  doc.getElementById('rtX').value = '-250';
  await H.get('addLineToBill')('procedure', 'nmX', 'qtX', 'rtX', null);
  ok(/negative/i.test(doc.getElementById('billEditorMsg').textContent),
     'add-line door refuses a negative rate');
  eq(H.get('currentDraftBill').items.length, 0, 'and nothing entered the bill');

  // 5. pending map doctrine on synthetic books
  H.set('getAllBills', async () => [
    { billId:'b1', patientId:'10001', status:'finalized', grandTotal:1000, date:'2026-08-01' },
    { billId:'b2', patientId:'10001', status:'finalized', grandTotal:400, date:'2026-08-02',
      cancellation:{ at:'2026-08-03' } },                       // cancelled — never existed
    { billId:'b3', patientId:'10002', status:'finalized', grandTotal:600, date:'2026-08-01' },
    { billId:'b4', patientId:'10002', status:'finalized', grandTotal:-600, date:'2026-08-05' }, // CN mirror
    { billId:'b5', patientId:'10003', status:'draft', grandTotal:999, date:'2026-08-01' },
  ]);
  H.set('getAllEntries', async () => [
    { date:'2026-08-01', items:[
      { id:'p1', patientId:'10001', method:'cash', amount:300 },
      { id:'p2', patientId:'10001', method:'upi', amount:200,
        reversal:{ reversedAt:'2026-08-04T10:00:00.000Z' } },   // reversed — out of balance
      { id:'p3', patientId:'10003', method:'cash', amount:250 }, // advance (no bill)
    ]},
    { date:'2026-08-02', items:[
      { id:'p4', patientId:'10001', method:'refund', amount:100 }, // handed back
    ]},
  ]);
  const P = await H.get('_perf__computeAllPatientPendingAmounts')();
  eq(P['10001'].pending, 800, 'pending: 1000 billed − (300 − 100 refund); cancelled bill + reversed payment out');
  eq(P['10002'].pending, 0, 'a CN exactly mirrors its sale');
  eq(P['10003'].pending, -250, 'payment with no bill is an advance (negative)');

  // 6. The visit-map gap found by this audit is now CLOSED (see
  //    test_visit_attendance.js for the full pin) — asserted here too so
  //    this probe stays a truthful record of the books.
  H.set('getAllLabCases', async () => []);
  H.set('getAllBills', async () => [
    { billId:'x1', patientId:'10004', patientName:'Lonely Cancel', status:'finalized',
      grandTotal:500, date:'2026-08-10', cancellation:{ at:'2026-08-10' } },
  ]);
  H.set('getAllEntries', async () => []);
  H.set('lastVisitMapCache', null);
  const seen2 = await H.get('_buildLastVisitMap')();
  ok(seen2.has('10004'),
     'a patient whose only trace is a cancelled bill HAS a visit on record (audit gap closed)');

  console.log('test_money_audit_probe: ' + n + ' assertions OK');
})().catch(e => { console.error(e); process.exit(1); });
