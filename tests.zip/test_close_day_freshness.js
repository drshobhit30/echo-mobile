/* H1 fix pinned: a Close Day written by the OTHER machine is seen by this
   tab's enforcement reads, immediately. Rules:
   1. refreshTodayLock() reads the disk, not the cache — the foreign lock is
      visible to every save-time re-check the moment it lands;
   2. frozenByLock then refuses for real against that fresh value;
   3. the per-render table read stays CHEAP (cached — no disk read per
      paint), and the refocus/idle sets forget the key so the drawing heals;
   4. close/reopen forget the cache before their read-modify-write. */
'use strict';
const assert = require('assert');
const fs = require('fs');
const { loadApp } = require('./harness/load_app');
const FILE = process.env.APP_FILE || 'echo-dental-collection-log.html';
const app = loadApp(FILE);
const H = app.__hook;
let n = 0; const ok = (c, m) => { assert(c, m); n++; };

(async () => {
  let diskReads = 0;
  let onDisk = JSON.stringify({});                     // no lock yet
  H.set('folderReady', () => true);
  H.set('_storeGetRaw', async (k) => {
    if(k !== 'day-locks') return null;
    diskReads++; return onDisk;
  });
  const today = H.get('todayStr')();

  ok((await H.get('refreshTodayLock')()) === null, 'no lock yet');

  // The ADMIN MACHINE closes the day — a foreign write this tab knows nothing about.
  const lockIso = new Date().toISOString();
  onDisk = JSON.stringify({ [today]: { lockedAt: lockIso, lockedBy: 'Admin' } });

  // Rule 1: the very next enforcement read sees it.
  const seen = await H.get('refreshTodayLock')();
  ok(seen === lockIso, 'save-time re-check sees the other machine\'s lock immediately');

  // Rule 2: and the guard refuses against it.
  ok(H.get('frozenByLock')('2000-01-01T00:00:00.000Z', seen) === true,
     'a record from before the close is frozen against the fresh lock');
  ok(H.get('frozenByLock')(new Date(Date.now()+60000).toISOString(), seen) === false,
     'a record entered after the close stays editable');

  // Rule 3a: the render path is the CACHED read — no disk read per paint.
  const before = diskReads;
  await H.get('dayLockedAt')(today);   // what buildPaymentsTableRows now calls
  ok(diskReads === before, 'render read is served from cache — no per-paint disk read');
  const src = fs.readFileSync(FILE, 'utf-8');
  ok(src.includes("const lockAt = (dateStr === todayStr()) ? await dayLockedAt(dateStr) : null;"),
     'payments table uses the cached read, not the disk one');

  // Rule 3b: refocus/idle heal the cached view.
  onDisk = JSON.stringify({});          // admin reopens the day
  ok((await H.get('dayLockedAt')(today)) === lockIso, 'cached view lags — expected');
  H.get('forgetDayLocksCache')();       // what refocus/idle now do
  ok((await H.get('dayLockedAt')(today)) === null, 'after refocus-forget, the cached view heals');
  ok((src.match(/forgetDayLocksCache\(\);/g) || []).length >= 4,
     'forget wired into refocus, idle refresh, close and reopen');

  console.log('test_close_day_freshness: ' + n + ' assertions OK');
})().catch(e => { console.error(e); process.exit(1); });
