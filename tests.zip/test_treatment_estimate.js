/* Treatment estimate: a proposal the patient takes away to think about.
   The rules that matter are the ones about money and survival, not the
   button:
   1. it is a DRAFT, so it touches no balance, no day total, no report —
      the whole point of "it should not impact the patient amount";
   2. it SURVIVES the overnight sweep that deletes stale drafts, which is
      the one thing that would silently destroy it;
   3. procedures only — pharmacy lines are stripped on conversion, and the
      pharmacy half of the editor is hidden so none can be added back;
   4. accepting it later bills it TODAY: the number comes from today's
      series and the money lands in today's collection, never back-dated
      into a closed day;
   5. it appears on the patient's timeline while waiting, with the doctor's
      note, and again as "accepted — billed" once finalised;
   6. a note is required — an estimate nobody can read later is a puzzle,
      not a record. */
'use strict';
const assert = require('assert');
const { loadApp } = require('./harness/load_app');
const app = loadApp(process.env.APP_FILE || 'echo-dental-collection-log.html');
const H = app.__hook;
let n = 0; const ok = (c, m) => { assert(c, m); n++; };
const eq = (a, b, m) => { assert.strictEqual(a, b, m + ` (got ${a}, want ${b})`); n++; };

const mkItem = (id, cat, amt) => ({ id, category: cat, name: id, qty: 1, rate: amt, discPct: 0, amount: amt });
const draft = () => ({ billId: 'b1', patientId: '10001', patientName: 'Sample', status: 'draft',
  date: '2026-08-01', items: [mkItem('P1','procedure',5000), mkItem('PH1','pharmacy',300)],
  subtotal: 5300, grandTotal: 5300, pharmDiscount: 0 });

(async () => {
  H.set('folderReady', () => true);
  H.set('todayStr', () => '2026-08-24');
  const saves = [];
  H.set('saveBill', async (b) => { saves.push(b); return 'ok'; });
  H.set('addBillLogEntry', async () => true);
  /* The two list refreshes the conversion fires. Stubbed so a genuine
     failure stands out instead of hiding in a stack trace from the shim
     trying to read a storage folder that does not exist here. */
  H.set('renderBillingDrafts', async () => true);
  H.set('renderBillingStatsCards', async () => true);
  H.set('closeBillEditor', () => true);
  app.window.alert = () => true;
  app.window.confirm = () => true;
  app.window.prompt = () => 'RCT on 26, patient will confirm after payday';

  // ---- 3 + 6: conversion strips pharmacy, keeps the note
  const b = draft();
  H.set('currentDraftBill', b);
  await H.get('convertDraftToEstimate')();
  eq(b.items.length, 1, 'the pharmacy line is gone');
  eq(b.items[0].category, 'procedure', 'the procedure stays');
  ok(b.estimate && b.estimate.note.indexOf('payday') !== -1, 'the doctor\u2019s note is stored');
  eq(b.status, 'draft', 'it is still a draft');
  ok(H.get('isTreatmentEstimate')(b), 'and recognised as an estimate');

  // a note is not optional
  const b2 = draft();
  H.set('currentDraftBill', b2);
  app.window.prompt = () => '   ';
  await H.get('convertDraftToEstimate')();
  ok(!b2.estimate, 'no note, no estimate');
  app.window.prompt = () => 'Crown on 36';

  // ---- 1: money is untouched
  const pendingSkipsDrafts = (bill) => bill.status === 'draft';
  ok(pendingSkipsDrafts(b), 'still a draft, so every money path skips it');

  // ---- 2: survives the overnight sweep
  const old = Object.assign(draft(), { billId:'b9', date:'2026-08-01' });
  old.estimate = { postedAt:'2026-08-01T10:00:00.000Z', postedOn:'2026-08-01', note:'x' };
  const plainStale = Object.assign(draft(), { billId:'b8', date:'2026-08-01' });
  const deleted = [];
  H.set('storeDelete', async (k) => { deleted.push(k); return 'ok'; });
  H.set('updateBillsIndex', async () => true);
  H.set('currentDraftBill', null);
  await H.get('autoDiscardStaleDrafts')([old, plainStale]);
  ok(deleted.indexOf('bill:b8') !== -1, 'an ordinary stale draft is still swept away');
  ok(deleted.indexOf('bill:b9') === -1, 'the ESTIMATE survives the night');

  // ---- 4: accepted today, billed today
  const acc = draft();
  acc.items = [mkItem('P1','procedure',5000)];
  acc.estimate = { postedAt:'2026-08-01T10:00:00.000Z', postedOn:'2026-08-01', note:'RCT' };
  acc.date = '2026-08-01';
  H.set('getNextBillNumber', async (d) => 'EDC/25-26/' + d);
  H.set('ensureUniqueBillNumber', async () => true);
  H.set('recomputeBillTotals', (x) => x);
  const res = await H.get('finalizeBillRecord')(acc);
  ok(res.ok, 'it finalises');
  eq(acc.date, '2026-08-24', 'the bill is dated the day the patient agreed');
  ok(String(acc.billNumber).indexOf('2026-08-24') !== -1, 'and numbered from that day\u2019s series');
  eq(acc.status, 'finalized', 'now a real bill');
  ok(H.get('wasTreatmentEstimate')(acc), 'and still knows it began as an estimate');
  ok(!H.get('isTreatmentEstimate')(acc), 'while no longer counting as one');

  /* ---- reachable later, which is the whole point ----
     Every list used to route a bill by DATE: today's opens the editor,
     anything older opens the read-only record view. That was right while
     drafts died overnight, and wrong the moment one was meant to outlive
     its day — the estimate became viewable but not finishable. */
  H.set('todayStr', () => '2026-09-10');
  const est = draft();
  est.date = '2026-08-01';
  est.estimate = { postedAt:'2026-08-01T10:00:00.000Z', postedOn:'2026-08-01', note:'RCT' };
  const plainOld = Object.assign(draft(), { billId:'b7', date:'2026-08-01', status:'finalized' });
  ok(/resumeDraftBill/.test(H.get('billRowOpenAction')(est)),
     'a weeks-old estimate opens in the EDITOR, so it can still be finalised');
  ok(/openTimelineRecordView/.test(H.get('billRowOpenAction')(plainOld)),
     'while an ordinary older bill still opens read-only');
  ok(/resumeDraftBill/.test(H.get('billRowOpenAction')(Object.assign(draft(), { date:'2026-09-10' }))),
     'and today\u2019s draft is unchanged');

  /* ---- it leaves the "Incomplete Bills" pile ----
     That list is reception's do-something-about-it pile. An estimate is
     finished work waiting on a patient, so leaving it there would make the
     pile look permanently untidy and train people to ignore it. */
  const fs2 = require('fs');
  const src2 = fs2.readFileSync(process.env.APP_FILE || 'echo-dental-collection-log.html', 'utf-8');
  ok(/const drafts = all\.filter\(b => b\.status === 'draft' && !isTreatmentEstimate\(b\)\)\s*\n?\s*\.sort/.test(src2),
     'the Incomplete Bills list excludes estimates');
  ok(/const drafts = all\.filter\(b => b\.status === 'draft' && !isTreatmentEstimate\(b\)\);\s*\n\s*const todayDs/.test(src2),
     'and so does the count on the stat card');
  ok(/const estimates = sameDay\.filter\(b => isTreatmentEstimate\(b\)\)/.test(src2),
     'the same-day warning names estimates separately from incomplete drafts');
  ok(/closeBillEditor\(\);[\s\S]{0,400}await renderBillingDrafts\(\);\s*\n\s*await renderBillingStatsCards\(\);/.test(src2),
     'posting closes the editor and refreshes both lists it just left');

  /* ---- the printed sheet ----
     A document that can be mistaken for a bill is a payment demand the
     clinic never made, so the sheet says what it is in five places: the
     stamp across the page, the title, the number line, the banner, and the
     footer. Decided from the RECORD, so every print route is covered. */
  const printed = H.get('buildBillPageHtml')(Object.assign(draft(), {
    items: [mkItem('P1','procedure',5000)],
    estimate: { postedAt:'2026-08-01T10:00:00.000Z', postedOn:'2026-08-01', note:'RCT on 26' }
  }));
  /* No diagonal watermark on an estimate or a draft: it printed across the
     items, cost ink on every copy, and made the figures harder to read on
     the one document whose whole job is to be read and thought about. Said
     at the top in words instead. CANCELLED keeps its stamp — a dead
     document should be unusable at a glance, the opposite requirement. */
  ok(printed.indexOf('billpage-estimate-stamp') === -1
     && printed.indexOf('billpage-preview-stamp') === -1, 'no watermark across the page');
  ok(/bee-title">TREATMENT ESTIMATE \u2014 this is not a bill</.test(printed),
     'it says so at the top instead');
  ok(printed.indexOf('Treatment Estimate') !== -1, 'titled an estimate, not a Patient Bill');
  ok(printed.indexOf('ESTIMATE \u2014 not a bill') !== -1, 'the bill-number line says so too');
  ok(printed.indexOf('this is not a bill') !== -1 && printed.indexOf('No payment is due') !== -1,
     'the banner tells the patient plainly that nothing is owed');
  /* The note is INTERNAL: timeline and bill log yes, patient's copy no. It
     is the clinic's record of the reasoning and can be franker than
     anything written to be read by the person it concerns. */
  ok(printed.indexOf('RCT on 26') === -1, 'the doctor\u2019s note does NOT print on the patient\u2019s copy');
  ok(printed.indexOf('bee-note') === -1, 'and no empty slot is left where it used to be');
  ok(printed.indexOf('Estimated Total') !== -1 && printed.indexOf('(Not payable yet)') !== -1,
     'the total is not presented as payable');
  ok(printed.indexOf('TREATMENT ESTIMATE \u2014 not a bill') !== -1, 'and the footer repeats it');
  ok(printed.indexOf('Patient Bill') === -1, 'the words "Patient Bill" appear nowhere on it');

  // the accepted bill is an ordinary bill again — no estimate wording left
  const billed = H.get('buildBillPageHtml')(Object.assign(draft(), {
    items: [mkItem('P1','procedure',5000)], status:'finalized', billNumber:'EDC/25-26/1',
    finalizedAt:'2026-09-10T10:00:00.000Z',
    estimate: { postedAt:'2026-08-01T10:00:00.000Z', postedOn:'2026-08-01', note:'RCT on 26' }
  }));
  ok(billed.indexOf('billpage-estimate-banner') === -1, 'once billed, no estimate banner');
  /* A cancelled bill still gets stamped — that treatment was not touched. */
  const cancelledSheet = H.get('buildBillPageHtml')(Object.assign(draft(), {
    items:[mkItem('P1','procedure',5000)], status:'finalized', billNumber:'EDC/25-26/2',
    finalizedAt:'2026-08-24T10:00:00.000Z',
    cancellation:{ cancelledAt:'2026-08-24T18:00:00.000Z', cancelledBy:'Admin', reason:'error' } }));
  ok(/billpage-cancelled-stamp">CANCELLED</.test(cancelledSheet),
     'a cancelled bill is still stamped across the page');
  ok(billed.indexOf('Patient Bill') !== -1 && billed.indexOf('(Payable Bill)') !== -1,
     'it prints as an ordinary bill');

  /* ---- the timeline entry opens the EDITOR ----
     Every route to a bill must agree about what an estimate is. The billing
     lists were fixed for this and the timeline was missed, so it opened the
     read-only record view: visible, but impossible to finish from. */
  {
    const est2 = Object.assign(draft(), { billId:'t1',
      items:[mkItem('P1','procedure',5000)],
      estimate:{ postedAt:'2026-08-01T10:00:00.000Z', postedOn:'2026-08-01', note:'RCT' } });
    const plain2 = Object.assign(draft(), { billId:'t2', status:'finalized', billNumber:'X/1',
      items:[mkItem('P1','procedure',5000)], finalizedAt:'2026-08-01T10:00:00.000Z' });
    delete plain2.estimate;
    H.set('getBill', async (id) => id === 't1' ? est2 : plain2);
    let resumed = null, viewed = false;
    H.set('resumeDraftBill', async (id) => { resumed = id; });
    H.set('switchReceptionTab', () => {});
    H.set('renderBillEditor', () => {});
    H.set('buildBillPageHtml', () => { viewed = true; return '<div></div>'; });
    await H.get('openTimelineRecordView')({ type:'bill', billId:'t1' });
    ok(resumed === 't1' && !viewed, 'the timeline opens an estimate in the editor');
    resumed = null; viewed = false;
    await H.get('openTimelineRecordView')({ type:'bill', billId:'t2' });
    ok(resumed === null && viewed, 'while an ordinary bill still opens read-only');
  }

  console.log('test_treatment_estimate: ' + n + ' assertions OK');
})().catch(e => { console.error(e); process.exit(1); });
