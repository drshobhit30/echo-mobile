/* Mobile Day view: Payments and Bills fold. Tested at the behaviour level by
   running the shipped wireCollapsibleSection source (extracted verbatim from
   index.html — the mobile page's Google deps make a full boot pointless here)
   against the DOM shim. Rules pinned:
   1. both section heads exist in the markup, chevron included, lists intact;
   2. a tap folds (list hidden, chevron class, aria says closed), a second
      tap unfolds;
   3. the choice persists in localStorage and is re-applied on next load;
   4. the fold class lives on the LIST CONTAINER, which renders replace the
      innerHTML of but never rebuild — so a re-render cannot silently unfold;
   5. the desktop file is untouched by this feature. */
'use strict';
const assert = require('assert');
const fs = require('fs');
const vm = require('vm');
const { makeDocument, makeLocalStorage } = require('./harness/dom_shim');
let n = 0; const ok = (c, m) => { assert(c, m); n++; };

const html = fs.readFileSync(process.env.MOBILE_FILE || 'index.html', 'utf-8');

// ---- rule 1: markup and styling shipped -----------------------------------
ok(html.includes('id="paySecHead"') && html.includes('id="billSecHead"'), 'both heads present');
ok((html.match(/sec-chev/g) || []).length >= 3, 'chevron markup + CSS present');
ok(html.includes('.pay-list.sec-hidden{ display:none; }'), 'hidden rule shipped');
ok(html.includes('id="payList"') && html.includes('id="dayBillList"'), 'lists still there');

// ---- extract the shipped function + wiring verbatim -------------------------
const m = html.match(/function wireCollapsibleSection[\s\S]*?\n}\n(wireCollapsibleSection\([^\n]*\n){2}/);
ok(!!m, 'wireCollapsibleSection and both wiring calls found in the page');
const src = m[0];
ok(src.includes("'echoDental_dayPayFolded'") && src.includes("'echoDental_dayBillFolded'"),
   'per-section storage keys, app prefix');

function bootFold(storage){
  const document = makeDocument();
  const sandbox = { document, localStorage: storage };
  vm.createContext(sandbox);
  vm.runInContext(src, sandbox);
  return document;
}

// ---- rules 2 + 3: fold, unfold, persist -------------------------------------
const store = makeLocalStorage();
let doc = bootFold(store);
const head = doc.getElementById('paySecHead');
const list = doc.getElementById('payList');
ok(!list.classList.contains('sec-hidden'), 'starts open');
head.click();
ok(list.classList.contains('sec-hidden'), 'tap folds the list');
ok(head.classList.contains('sec-closed'), 'chevron state follows');
ok(head.getAttribute('aria-expanded') === 'false', 'aria says closed');
ok(store.getItem('echoDental_dayPayFolded') === '1', 'choice persisted');
head.click();
ok(!list.classList.contains('sec-hidden') && store.getItem('echoDental_dayPayFolded') === '0',
   'second tap unfolds and persists that too');

// Bills fold independently.
const bHead = doc.getElementById('billSecHead');
bHead.click();
ok(doc.getElementById('dayBillList').classList.contains('sec-hidden')
   && !list.classList.contains('sec-hidden'), 'bills fold without touching payments');

// Next load re-applies the remembered state.
store.setItem('echoDental_dayPayFolded', '1');
doc = bootFold(store);
ok(doc.getElementById('payList').classList.contains('sec-hidden'), 'remembered fold re-applied on load');
ok(doc.getElementById('paySecHead').getAttribute('aria-expanded') === 'false', 'aria re-applied too');

// ---- rule 4: re-render survives the fold ------------------------------------
doc.getElementById('payList').innerHTML = '<div class="pay-row">new day</div>';
ok(doc.getElementById('payList').classList.contains('sec-hidden'),
   're-render replaces content, not the fold');

// ---- rule 5 + cache bump ----------------------------------------------------
/* Paths are EXPLICIT. These two used to be cwd-relative, which read whatever
   stale copies happened to sit in the working directory — this test "failed"
   against a v11 sw.js that was eighteen builds old while the real one was
   fine. A test that can silently pick up the wrong file is worse than none. */
const path = require('path');
const DESK = process.env.APP_FILE || 'echo-dental-collection-log.html';
const SW = process.env.SW_FILE || path.join(path.dirname(process.env.MOBILE_FILE || 'index.html'), 'sw.js');
ok(!fs.readFileSync(DESK, 'utf-8').includes('wireCollapsibleSection'),
   'desktop file untouched by the mobile fold');
ok(/CACHE_VERSION = 'echo-nexus-v23'/.test(fs.readFileSync(SW, 'utf-8')),
   'service worker cache bumped so the phone picks this up');

console.log('test_mobile_collapse: ' + n + ' assertions OK');
