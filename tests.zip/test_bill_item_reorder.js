/* Reordering the lines on a bill. The rule that matters is that this is a
   PRESENTATION change only: a permutation cannot change a sum, and if any
   figure moves, the feature is wrong however nice the arrows look.
   Rules:
   1. a move swaps with the nearest neighbour IN THE SAME CATEGORY, because
      the printed bill groups by category — moving a procedure below a
      pharmacy line would reorder the array and change nothing on the page;
   2. other-category rows in between are hopped over and keep their own
      relative order;
   3. no money changes: same items, same amounts, same subtotal, same grand
      total, before and after;
   4. the ends of a section are no-ops, not errors;
   5. a frozen (cancelled) bill refuses the move and says so — the same
      guard Remove carries, because this writes on its own;
   6. the arrows only render when the bill is editable, and are disabled
      rather than hidden at the ends, so controls do not shuffle about;
   7. permission is exactly the existing edit window — reception on the day
      of finalisation, admin any time — not a new rule. */
'use strict';
const assert = require('assert');
const fs = require('fs');
const { loadApp } = require('./harness/load_app');
const FILE = process.env.APP_FILE || 'echo-dental-collection-log.html';
const app = loadApp(FILE);
const H = app.__hook;
let n = 0; const ok = (c, m) => { assert(c, m); n++; };
const eq = (a, b, m) => { assert.strictEqual(a, b, m + ` (got ${a}, want ${b})`); n++; };

const saved = [];
H.set('folderReady', () => true);
H.set('saveBill', async (b) => { saved.push(JSON.parse(JSON.stringify(b))); return 'ok'; });

const mk = (id, cat, amount) => ({ id, category: cat, name: id, qty: 1, rate: amount, discPct: 0, amount });
const ids = () => H.get('currentDraftBill').items.map(i => i.id).join(',');
const money = () => {
  const b = H.get('currentDraftBill');
  return b.items.reduce((s, i) => s + i.amount, 0);
};

(async () => {
  // P1 PH1 P2 PH2 P3 — deliberately interleaved, which is the case that
  // separates a correct implementation from a naive index swap.
  const items = [mk('P1','procedure',100), mk('PH1','pharmacy',10), mk('P2','procedure',200),
                 mk('PH2','pharmacy',20), mk('P3','procedure',300)];
  H.set('currentDraftBill', { billId:'b1', patientId:'10001', patientName:'A', status:'draft',
                              items, subtotal:630, grandTotal:630, pharmDiscount:0, date:'2026-08-24' });
  const before = money();

  // 1 + 2 — P1 down swaps with P2, hopping PH1, which stays put
  await H.get('moveBillLineItem')('P1', 1);
  eq(ids(), 'P2,PH1,P1,PH2,P3', 'moved to the next PROCEDURE, hopping the pharmacy row');
  // 3
  eq(money(), before, 'not one rupee moved');
  eq(H.get('currentDraftBill').items.length, 5, 'and nothing was lost');

  // pharmacy moves within its own category too
  await H.get('moveBillLineItem')('PH1', 1);
  eq(ids(), 'P2,PH2,P1,PH1,P3', 'a pharmacy line swaps with the next pharmacy line');

  // 4 — the ends of a section do nothing
  const atEnd = ids();
  await H.get('moveBillLineItem')('P2', -1);     // first procedure
  eq(ids(), atEnd, 'first in its section cannot move up');
  await H.get('moveBillLineItem')('P3', 1);      // last procedure
  eq(ids(), atEnd, 'last in its section cannot move down');
  ok(!H.get('canMoveBillItem')(H.get('currentDraftBill').items, 'P2', -1), 'and the button knows it');
  ok(H.get('canMoveBillItem')(H.get('currentDraftBill').items, 'P2', 1), 'while a legal move is offered');

  // 5 — a cancelled bill refuses
  const cancelled = { billId:'b2', patientId:'10001', patientName:'A', status:'finalized',
                      items:[mk('X1','procedure',100), mk('X2','procedure',200)],
                      subtotal:300, grandTotal:300, pharmDiscount:0, date:'2026-08-24',
                      finalizedAt:'2026-08-24T10:00:00.000Z',
                      cancellation:{ cancelledAt:'2026-08-24T18:00:00.000Z', by:'Admin', reason:'error' } };
  H.set('currentDraftBill', cancelled);
  const savesBefore = saved.length;
  await H.get('moveBillLineItem')('X1', 1);
  eq(ids(), 'X1,X2', 'a cancelled bill does not reorder');
  eq(saved.length, savesBefore, 'and nothing was written');

  // 6 + 7, read from the source: same window as Edit/Remove, disabled not hidden
  const src = fs.readFileSync(FILE, 'utf-8');
  ok(/canEditItems\s*\n?\s*\?\s*'<button class="link-btn bill-move-btn"/.test(src.replace(/\r/g,''))
     || /\(canEditItems[\s\S]{0,80}bill-move-btn/.test(src),
     'the arrows hang off canEditItems — the existing permission, not a new one');
  ok(/canMoveBillItem\(currentDraftBill\.items, it\.id, -1\) \? '' : ' disabled'/.test(src),
     'disabled at the top of a section rather than removed');
  ok(/\.bill-move-btn\[disabled\]\{[^}]*pointer-events:none/.test(src),
     'and a disabled arrow cannot be clicked');
  ok(/if\(billIsFrozen\(currentDraftBill\)\)\{[\s\S]{0,220}frozenBillMessage\(\)/.test(src),
     'the frozen-bill guard is stated in the handler itself');

  console.log('test_bill_item_reorder: ' + n + ' assertions OK');
})().catch(e => { console.error(e); process.exit(1); });
