/* Structural sweep: the things a parse alone would not catch.
   REWRITTEN 24 Aug 2026 (evening). The previous version of this file
   described the MORNING build (2026-08-24g) — it asserted the conflict
   banner, refocus threshold, restore index-reset and Close Day fix were
   PRESENT, all of which were deliberately dropped in the rollback. It kept
   "passing" because it read cwd-relative paths and found a stale pre-
   rollback copy sitting in the working directory. Both faults are fixed
   here: explicit paths, and assertions that state the AGREED build —
   including pinning the rolled-back features ABSENT, so if one creeps back
   it is a conscious decision that updates this file, not an accident. */
'use strict';
const assert = require('assert');
const fs = require('fs');
const path = require('path');
let n = 0; const ok = (c, m) => { assert(c, m); n++; };

const DESK = process.env.APP_FILE || 'echo-dental-collection-log.html';
const MOB = process.env.MOBILE_FILE || 'index.html';
const SW = process.env.SW_FILE || path.join(path.dirname(MOB), 'sw.js');
const d = fs.readFileSync(DESK, 'utf-8');
const m = fs.readFileSync(MOB, 'utf-8');

// The build line: renumbered after the rollback, one bump per shipped change.
ok(/const APP_BUILD = '2026-08-2\d-lab\+\d+';/.test(d),
   'desktop stamp is the post-rollback lab+N series');

// ---- ABSENT, by the rollback decision — the mirror of the four
// expected-fail tests. If any of these appears, the suite runner will also
// shout UNEXPECTED PASS on the matching test; this line names it here too.
/* The conflict banner is CANCELLED outright (user decision, 24 Aug) — not
   deferred like the two below it. The merge it reported on is untouched. */
/* Only the warm-up and the conflict banner remain out: the warm-up caused
   the blank screen, the banner was cancelled outright. The other three
   rolled-back features were re-applied on 25 Aug. */
for(const gone of ['warmStorageCaches', 'writeConflictBanner']){
  ok(!d.includes(gone), 'rolled back and must stay out until re-applied: ' + gone);
}

// ---- PRESENT: what survived the rollback re-apply.
ok(d.includes('LABCASES_INDEX_VERSION'), 'lab-cases index shipped');
ok(d.includes('adminDefaultPwNote'), 'default-password notice shipped');
ok(d.includes('Attendance, not money.'), 'visit-map attendance rule shipped');
ok((d.match(/Sent to Lab/g) || []).length >= 5, 'lab stage renamed at every surface');
ok(!d.includes("sent:'Sent',"), 'no stale sent label in LAB_STATUS_LABELS');
ok(d.includes('function stripExemptFromFollowupNote'), 'note-strip helper shipped');
ok(d.includes('function forgetDayLocksCache'), 'Close Day cross-machine freshness re-applied');
ok(d.includes('async function resetDerivedIndex'), 'restore index-reset re-applied');
ok(d.includes('const REFOCUS_TRUST_MS = 15000'), 'refocus threshold re-applied');
ok(d.includes('function collapseDuplicateOpenTasks'), 'one-open-task rule enforced in the save funnel');
ok(d.includes('async function declineTreatmentEstimate'), 'estimates can be declined, not only discarded');
ok(d.includes('function stampEstimateRevision'), 'a printed estimate that changes is marked revised');
ok(d.includes('async function renderReviewNotesBanner'), 'consultation notes can be raised at the next visit');
ok((d.match(/stripExemptFromFollowupNote\(/g) || []).length >= 5,
   'helper used at creation AND both legacy render sites');
/* "Send" on a case that has already come back reads as sending a NEW case.
   The tooltip always said "Send back to the lab" — but nobody hovers on a
   busy screen, so the label now says it. */
ok(d.includes("actBtn('\u21bb', 'Send Back', 'Send back to the lab'"), 'Send-again button reads Send Back');

// ---- PRESENT: today's evening features, one landmark each.
ok(d.includes('function isTreatmentEstimate'), 'treatment estimates shipped');
ok(d.includes('&& !isTreatmentEstimate(b));'), 'and exempt from the overnight draft sweep');
ok(d.includes('function billRowOpenAction'), 'one rule for how a bill row opens');
ok(d.includes('tlSubTabBtn_estimates'), 'the Estimates tab on the patient page');
ok(d.includes('billPharmDiscountRow'), 'pharmacy discount row hideable on estimates');
ok(d.includes('function moveBillLineItem'), 'bill item reorder shipped');
ok(d.includes('sectionTotalRowHtml'), 'printed section totals shipped');
ok(d.includes('billpage-estimate-banner'), 'estimate/draft banners on the printed page');
ok(!d.includes('billpage-estimate-stamp') && !d.includes('billpage-preview-stamp'),
   'and the diagonal watermarks are gone');
ok(d.includes('billpage-cancelled-stamp">CANCELLED'), 'while CANCELLED keeps its stamp');
ok(!d.includes('billpage-section-subtotal'), 'dead subtotal CSS fully removed');

// ---- landmarks from prior sessions survive the day's edits.
for(const mark of ['day-locks.json', 'billIsFrozen', 'ensureUniqueBillNumber', 'entries-index',
                   'Money Moved', 'Collection by Doctor']){
  ok(d.includes(mark), 'landmark intact: ' + mark);
}
for(const mark of ['ortho-patients.json', 'entries-index', 'serviceWorker']){
  ok(m.includes(mark), 'mobile landmark intact: ' + mark);
}
ok(m.includes('Echo Nexus'), 'mobile branding intact');
ok(/CACHE_VERSION = 'echo-nexus-v25'/.test(fs.readFileSync(SW, 'utf-8')),
   'mobile service worker at v14');

console.log('test_static_checks: ' + n + ' assertions OK');
