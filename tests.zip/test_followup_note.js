/* Follow-up notes ignore exempt procedures (Consultation, X-Ray, Medicines by
   default — the admin-editable list). The RULES pinned here:
   1. exempt names are stripped from what the note SAYS;
   2. exemption still decides WHETHER a follow-up exists (unchanged rule);
   3. a note that would strip to nothing keeps its original text — a legacy
      record from before the exempt list must not go blank;
   4. matching is name-exact (OPG is not covered by "X-Ray"), same as the
      exemption rule itself. */
'use strict';
const assert = require('assert');
const { loadApp } = require('./harness/load_app');
const app = loadApp(process.env.APP_FILE || 'echo-dental-collection-log.html');
const H = app.__hook;
let n = 0; const ok = (c, m) => { assert(c, m); n++; };

const strip = H.get('stripExemptFromFollowupNote');
ok(strip('Consultation, Root Canal Treatment, X-Ray') === 'Root Canal Treatment',
   'exempt names dropped around the real procedure');
ok(strip('Root Canal Treatment') === 'Root Canal Treatment', 'clean note untouched');
ok(strip('Consultation, X-Ray') === 'Consultation, X-Ray',
   'all-exempt legacy note keeps its original text rather than going blank');
ok(strip('') === '' && strip(null) === '', 'empty stays empty');
ok(strip('OPG, Consultation') === 'OPG', 'exact-name rule: OPG is not "X-Ray", so it stays');
ok(strip('consultation, Scaling') === 'Scaling', 'case-insensitive match, same as exemption');

// What a new record stores (candidateProcedureLabel feeds the saved note).
const label = H.get('candidateProcedureLabel');
ok(label({ procedures: ['Consultation', 'Extraction'], noteText: '' }) === 'Extraction',
   'stored note for a new follow-up is already clean');
ok(label({ procedures: [], noteText: 'X-Ray, Tooth Filling' }) === 'Tooth Filling',
   'payment-note path cleaned the same way');
ok(label({ procedures: [], noteText: '' }) === H.get('FOLLOWUP_NO_DETAIL_LABEL'),
   'no detail at all still says "Check patient history"');

// Rule 2 unchanged: exemption still gates existence.
ok(H.get('candidateNeedsFollowup')({ procedures: ['Consultation', 'X-Ray'], noteText: '' }) === false,
   'exempt-only visit still raises no follow-up');
ok(H.get('candidateNeedsFollowup')({ procedures: ['Consultation', 'Extraction'], noteText: '' }) === true,
   'mixed visit still raises one');

console.log('test_followup_note: ' + n + ' assertions OK');
